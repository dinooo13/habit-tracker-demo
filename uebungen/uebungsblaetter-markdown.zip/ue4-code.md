# Ü4 Code-Skill und erster `/code`-Lauf

**Tag 2 · Donnerstag 19.11., am Vormittag · Zeitbox 65 Minuten**

## Ziel

Ihr schreibt einen `code`-Skill, der eine freigegebene Spec Task für Task umsetzt: Test zuerst, ein Commit pro Task, Gates am Ende. Unabhängige Tasks arbeitet er parallel in Subagenten ab, der Hauptagent orchestriert und committet. Dann lasst ihr ihn in einer neuen Session auf eurer Spec laufen.

**Done, wenn …**

- [ ] `.claude/skills/code/SKILL.md` existiert und als **harte Regel** sagt: kein Produktionscode, bevor der Test des Tasks rot war; ein Conventional Commit pro Task; Gates am Ende grün; Start nur bei `Status: approved`,
- [ ] der Skill regelt die **parallelen Tasks**: Er prüft vorab selbst, welche Tasks unabhängig sind (braucht kein Ergebnis eines anderen Tasks, fasst keine gleichen Dateien an), je ein Subagent pro unabhängigem Task, TDD pro Task, der Hauptagent committet Task für Task, die Gates laufen am Ende,
- [ ] die Spec unverändert bleibt: keine Abhängigkeitsmarker, die Freigabe gilt weiter,
- [ ] `/code specs/<slug>.md` in einer **neuen Session** gelaufen ist,
- [ ] alle Tasks der Spec committet sind (`- [x]` in der Spec, ein Commit pro Task),
- [ ] die Gates grün sind (Weg B: `npm run lint && npm run typecheck && npm test`).

## Zeitplan

| Min. | Was |
|---|---|
| 0-5 | Blatt lesen. Stand prüfen: Ist eure Spec freigegeben? (`grep -n "Status:" specs/*.md`) |
| 5-22 | `code`-Skill schreiben, mit dem Abschnitt zu parallelen Tasks, committen |
| 22-28 | Rechte einrichten, neue Session, `/code specs/<slug>.md` starten |
| 28-50 | Lauf beobachten (Weg B ca. 10-15 Min.). Währenddessen im Raum die Commits der Musterlösung ansehen und Rückfragen des Agenten sofort beantworten |
| 50-58 | Ergebnis prüfen: Commits, Red-Zeilen, Gates |
| 58-65 | Im Raum vergleichen. Debrief-Person notiert den Debrief-Beitrag und postet ihn in den globalen Chat, aus dem Raum oder gleich nach der Rückkehr |

Der Kursleiter kommt reihum in die Räume. Wer hängt: erst die gestuften Hilfen unten im Übungsheft, dann die Gruppe, dann dem Kursleiter im globalen Chat schreiben (Raum und ein Satz).

**Spec noch nicht freigegeben?** Erst den Rückfall-Block von [Blatt Ü3](ue3-spec-voll-und-freigabe.md#rückfall) nehmen, dann hier weiter.

## Weg A: euer Repo

1. Skill aus der Vorlage übernehmen und anpassen, oder selbst schreiben (Gerüst in Hilfe 2):

   ```bash
   mkdir -p .claude/skills/code
   cp ../rheinwerk-starter-skills/.claude/skills/code/SKILL.md \
     .claude/skills/code/SKILL.md
   grep -n ANPASSEN .claude/skills/code/SKILL.md
   ```

   Zu füllen: Basis-Branch und Branch-Schema, schnelle Gates, E2E-Gate, Test-Ordner. **Keine E2E-Tests im Repo?** Schreibt bei E2E `none` hinein und löscht den E2E-Schritt. Dann trägt der Test-Plan der Spec die Last.

   Die Vorlage arbeitet die Tasks nacheinander ab. Fügt den Abschnitt „Plan the order“ aus Hilfe 2 vor „Each task“ ein. Darin analysiert der Skill vorab selbst, welche Tasks unabhängig sind, und startet nur für diese parallele Subagenten. Die Spec fasst ihr nicht an.
2. Committen:

   ```bash
   git add .claude/skills
   git commit -m "feat(skills): add the code skill"
   ```
3. **Rechte:** Im Firmen-Repo keinen Vollzugriff. Erlaubt gezielt eure Gate-Befehle sowie `git add` und `git commit` (Claude Code: Allow-Liste in `.claude/settings.local.json`, siehe Weg B, eure Befehle einsetzen). Alles andere bestätigt ihr einzeln.

   **Claude Code ab 2.1.283 startet im Auto-Modus** (Statuszeile `auto mode on`). Dann bestätigt ihr nicht einzeln, ein Klassifizierer-Modell prüft die Aktionen. Enge Allow-Regeln wie `Bash(npm test)` gelten weiter, breite wie `Bash(*)` setzt der Auto-Modus aus. Verlangt eure Firma Einzelfreigaben, stellt im Firmen-Repo auf den Standard-Modus:

   ```bash
   claude --permission-mode default
   ```

   In der Session wechselt Shift+Tab von `auto` auf `default`. Dauerhaft für alle eure Sessions: `"permissions": { "defaultMode": "default" }` in `~/.claude/settings.json`.
4. Neue Session, `/code specs/<slug>.md`. Rückfragen sofort beantworten.
5. Läuft der Lauf in eurem Repo deutlich länger als die Zeitbox (großer Build, langsame Tests)? Lasst ihn laufen und prüft parallel die Musterlösung in Weg B (Hilfe 3).

## Weg B: Demo-Fork

1. Auf `seminar/kategorien` den `code`-Skill schreiben (Gerüst in Hilfe 2, mit „Plan the order“). `specs/kategorien.md` bleibt, wie sie ist: Welche Tasks unabhängig sind, entscheidet der Skill beim Lauf selbst.
2. Committen:

   ```bash
   git add .claude/skills
   git commit -m "feat(skills): add the code skill"
   ```

3. Rechte für den Lauf, eine der beiden Varianten:
   - **Allow-Liste** (so würdet ihr es im Firmen-Repo machen). Datei `.claude/settings.local.json` anlegen. Sie ist persönlich, über `.git/info/exclude` (Ü2) wird sie nie committet:

     ```json
     {
       "env": { "PORT": "3110", "E2E_PORT": "3110" },
       "permissions": {
         "allow": [
           "Bash(gh issue view *)",
           "Bash(npm test)", "Bash(npm test *)",
           "Bash(npm run test:unit *)", "Bash(npm run test:nuxt *)",
           "Bash(npm run lint)", "Bash(npm run lint *)", "Bash(npm run lint:fix)",
           "Bash(npm run typecheck)",
           "Bash(npx vitest *)", "Bash(npx eslint *)",
           "Bash(PORT=3110 E2E_PORT=3110 npm run test:e2e)",
           "Bash(PORT=3110 E2E_PORT=3110 npm run test:e2e *)",
           "Bash(PORT=3110 E2E_PORT=3110 npx playwright test *)",
           "Bash(git add *)", "Bash(git commit *)",
           "Bash(git checkout -b *)", "Bash(git switch -c *)"
         ]
       }
     }
     ```

   - **Auto-Modus bzw. Vollzugriff:** im Demo-Fork vertretbar (keine Secrets, eigener Fork). Im Firmen-Repo nicht. Befehle pro Tool unter „Pro Tool“.
4. Neue Session:

   ```text
   /code specs/kategorien.md
   ```

   Achtet am Anfang darauf, welche Tasks der Agent als unabhängig einstuft, welche er parallel startet und welche er nacheinander lässt. Fragt euch: Hättet ihr genauso entschieden?
5. Während der Lauf geht (ca. 10-15 Min.), die Musterlösung ansehen, jede/r für sich oder gemeinsam, wenn jemand den Bildschirm teilen mag:

   ```bash
   git log --oneline --no-merges origin/stufe/02-spec-voll..origin/stufe/03-code
   ```

   10 Commits: der Skill, die Freigabe, 7 Tasks = 7 Commits und der Nachtrag `5d1aaeb` zur TDD-Regel. Einen Task-Commit öffnen: `git show --stat 3112d3f`.
6. Nach dem Lauf prüfen:

   ```bash
   git log --oneline --no-merges origin/main..HEAD
   git log --no-merges --format="%h %s%n%b" origin/main..HEAD \
     | grep -E "^[0-9a-f]{7}|Red:"
   grep -n "\- \[" specs/kategorien.md
   npm run lint && npm run typecheck && npm test
   ```

   Abweichungen zur Musterlösung (andere Dateinamen, andere Tests) sind normal. Genau deshalb prüft `/verify` in Ü5 gegen die Spec und nicht gegen einen Referenz-Diff.

## Pro Tool

| Tool | Neue Session | Rechte für den Lauf | Hinweis |
|---|---|---|---|
| Claude Code | `/clear` oder neu starten | Allow-Liste (oben) oder Auto-Modus (ab 2.1.283 Start-Modus; sonst `claude --permission-mode auto` bzw. Shift+Tab bis „auto mode on“). Einzelfreigaben: `claude --permission-mode default`. Im Demo-Fork auch ohne Rechte-Abfragen (Kasten unter der Tabelle) | `disable-model-invocation: true` im Frontmatter: `/code` startet nur, wenn ihr es tippt |
| Codex | `/new` | `/permissions`. Startet der Browser für E2E in der Sandbox nicht, im Demo-Fork Full Access | Skill spiegeln (Kasten unter der Tabelle) und mit `$code specs/kategorien.md` aufrufen |
| Cursor | neuer Chat | Auto-Run für Terminal-Befehle in den Cursor-Einstellungen, im Firmen-Repo nur mit Allowlist | Lange Läufe: Chat offen lassen, Rückfragen kommen dort |
| Copilot | neuer Chat, CLI `/clear` | VS Code: Terminal-Befehle einzeln bestätigen oder Auto-Approve laut Doku. CLI: `/allow-all` nur im Demo-Fork | Business/Enterprise: Admin muss Terminal im Agent-Modus erlauben. VS Code: Skill nach `.github/skills/` spiegeln, falls `/code` fehlt |

Claude Code im Demo-Fork ohne Rechte-Abfragen (nie im Firmen-Repo):

```bash
claude --dangerously-skip-permissions
```

Codex, Skill spiegeln (im Repo-Ordner):

```bash
mkdir -p .agents && cp -R .claude/skills .agents/
```

**Subagenten für parallele Tasks** gibt es in Claude Code, Codex, Cursor und Copilot. Wo eigene Subagenten liegen, zeigt das Tool-Mapping im README des Übungshefts (Zeile „Subagenten“). Für `/code` braucht ihr keinen eigenen Subagenten, der Skill startet pro Task einen. Codex startet Subagenten nur, wenn man es ausdrücklich verlangt: Der Satz „start one subagent per task“ im Skill tut genau das. Startet euer Tool trotzdem keine, arbeitet der Skill die Tasks nacheinander ab. Das ist kein Fehler, nur langsamer.

Für alle Tools gilt: Die Spec ist die Wahrheit. Ein Lauf in einer neuen Session sieht nur Spec, `AGENTS.md` und Repo, nicht euren Chat von gestern.

## Gestufte Hilfen

<details>
<summary>Hilfe 1: Denkanstoß</summary>

- „Schreib Tests“ reicht nicht. Agenten schreiben Test und Code gern zusammen. Die Regel muss hart sein: **Test ausführen, Fehlschlag zeigen, erst dann Code.** Und prüfbar: der Name des roten Tests steht im Commit (`Red: <test>`).
- Ein Commit pro Task heißt: Der Skill hakt den Task in der Spec ab (`- [x]`). So kann eine neue Session nach einem Abbruch weitermachen.
- „Startet nur bei approved“: Der Skill liest die Kopfzeile. Steht `draft`, fragt er, statt loszulegen.
- Parallel lohnt sich nur bei wirklich unabhängigen Tasks. Unabhängig heißt: braucht kein Ergebnis eines anderen Tasks und fasst keine gleichen Dateien an. Zwei Tasks, die dieselbe Datei anfassen, sind nicht unabhängig, auch wenn keiner auf den anderen wartet.
- Wer entscheidet das? Der Skill, vor dem ersten Task, aus den Tasks, den genannten Dateien und dem Code. Die Spec bleibt dafür unverändert. Im Zweifel: nacheinander.
- Wer committet? Nur der Hauptagent. So bleibt ein Commit pro Task, in der Reihenfolge der Spec, und kein Subagent nimmt fremde Änderungen mit.

**Stolperstein: parallele Subagenten im selben Arbeitsverzeichnis.** Alle Subagenten schreiben in denselben Ordner und denselben Git-Index. Ein `git add -A` oder `npm run lint:fix` eines Subagenten erwischt die halbfertigen Dateien der anderen, ein Testlauf sieht fremden, roten Code. Deshalb: Subagenten committen nicht, laufen nur ihre eigenen Tests und fassen nur ihre Dateien an. Der Hauptagent committet mit `git add <pfade>`, nie mit `git add -A`. Die vollen Gates laufen erst am Ende, wenn alle fertig sind.

</details>

<details>
<summary>Hilfe 2: Gerüst zum Kopieren</summary>

````markdown
---
name: code
description: Implement an approved spec from specs/ task by task, test first.
argument-hint: "[specs/<slug>.md]"
disable-model-invocation: true
---

# Code

Implement the approved spec: **$ARGUMENTS**

## 1. Load the spec
- Read the whole spec. It is the scope: no more, no less.
- If the header says `Status: draft`, ask before you write code.
- Read the files under Research and the ADRs it names.

## 2. Branch
- Never work on `main`. Start from a clean tree and run the unit tests once.

## 3. Plan the order
- Before the first task, read all tasks and decide yourself which ones are
  independent: a task needs no result of another task and touches none of the
  same files. The spec does not mark this; work it out from the tasks and code.
- If dependencies or files are unclear, work those tasks one after the other.
- Independent tasks may run in parallel: start one subagent per task.
  Give it the spec path, its task and the files it may touch.
- A dependent task starts after the tasks it needs are committed.
- A subagent does Red, Green and Refactor for its task, runs only its own tests
  and reports back. It does not commit and touches no files outside its task.
- You orchestrate: check each result, then commit it as its own task commit,
  with `git add <paths>`, never `git add -A`.
- If you cannot start subagents, run all tasks one after the other.

## 4. Each task
1. **Red.** Write the test for the task and run it. It must fail for the right
   reason. **Hard rule: no production code before you have seen this test fail.**
   Show the command and the failing assertion. No testable behavior (ADR, docs)?
   Say `No test: <reason>`.
2. **Green.** Smallest change that makes it pass. Follow the patterns around it.
3. **Refactor** while green.
4. **Commit** one Conventional Commit per task, body line `Red: <test name>`.
   Tick the task in the spec (`- [x]`). Never commit a red state.

If a task is wrong or impossible, stop and tell the user. Do not change scope.

## 5. Gates
Only after the last task: <eure Gate-Befehle>.
Fix failures at the cause. Never weaken, skip or delete a test.

## 6. Report
Branch, commits, decisions on the way, gate results, open risks.
Suggest `/verify specs/<slug>.md`. Do not push, open a PR or merge.
````

</details>

<details>
<summary>Hilfe 3: Musterlösung ansehen</summary>

Der `code`-Skill mit parallelen Tasks. Die Spec ist dort unverändert, nur der Skill kommt hinzu:

```bash
P=origin/seminar/ue4-code-parallel
git show $P:.claude/skills/code/SKILL.md
git diff origin/stufe/03-code $P -- .claude/skills/code/
```

Der Lauf selbst, Commits und Diff (dort noch ohne parallele Tasks):

```bash
git log --oneline --no-merges origin/stufe/02-spec-voll..origin/stufe/03-code
git diff --stat origin/stufe/02-spec-voll origin/stufe/03-code
```

Ehrlich dazu: Die Feature-Commits der Musterlösung entstanden vor der TDD-Regel (Commit `5d1aaeb` „make TDD explicit“). Sie haben deshalb noch keine `Red:`-Zeile. Euer Lauf sollte sie haben.

Weg A: `.claude/skills/code/SKILL.md` in der Vorlage.

</details>

## Rückfall

Weg B: `/code` hängt, ist rot oder nicht fertig? Rest sichern und auf dem Stand der Musterlösung weitermachen. Dort ist das Feature fertig und die Spec freigegeben:

```bash
git add -A && git commit -m "wip: ue4 nicht fertig"
git switch --no-track -c seminar/ab-ue5 origin/stufe/03-code
```

Eure Skills und `AGENTS.md` nehmt ihr mit:

```bash
git checkout seminar/kategorien -- AGENTS.md .claude/skills
git commit -m "chore: eigene Skills übernehmen" || true
```

`|| true` fängt nur „nothing to commit“ ab: Sind eure Skills schon gleich, gibt es nichts zu committen, und das ist in Ordnung.

Ab jetzt arbeitet ihr auf `seminar/ab-ue5` statt `seminar/kategorien`. Codex: `.agents/skills` danach neu spiegeln, Copilot in VS Code ggf. `.github/skills`.

Weg A: Minimum für Ü5 ist ein Branch mit einer Änderung, die zu eurer Spec passt, auch wenn nur ein Teil der Tasks fertig ist. `/verify` darf dann „Issues found“ sagen, genau das übt ihr in Ü5.

## Bonus für Schnelle

- Den Lauf abbrechen (Ctrl-C bzw. Stopp) und in einer neuen Session `/code specs/<slug>.md` erneut starten. Macht er beim nächsten offenen Task weiter?
- Weg B: Issue #2 durch `/spec` und `/code` (Branch aus Ü3-Bonus).
- Vergleicht mit `git log --format="%h %ad %s" --date=iso`: Liegen die Task-Commits trotz paralleler Subagenten in der Reihenfolge der Spec?
- Prüft einen Commit von Hand: Hätte der Test ohne den Produktionscode wirklich versagt? `git show <sha> -- tests e2e`.

## Für den Debrief

Leitfrage: **Hat der Agent wirklich zuerst den Test geschrieben? Wie viele Commits?**

- Debrief-Beitrag (Debrief-Person, in den globalen Chat): Anzahl Commits, Anzahl mit `Red:`-Zeile, wie viele Tasks parallel liefen, Gates grün ja/nein, und eine Frage.
- Im Plenum zeigen zwei Räume `git log --oneline`. Der Kursleiter zeigt `git log` von Stufe 3.
