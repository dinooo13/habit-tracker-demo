# Team-Plan: Beispiel

Team: Buchung (fiktiv, 6 Devs, 1 Tech Lead, 1 PO)  ·  Repo: `booking-service`  ·  Ausgefüllt von: Dev A  ·  Datum: 19.11.2026

**Fiktives Beispiel, keine echte Firma.** Stack: Jira, GitLab mit CI, `backend/` in Java 21 mit Spring Boot, Gradle und Flyway, `bff/` in TypeScript mit Node 22. Agent: Claude Code mit Firmenlizenz, ein Teil des Teams nutzt Copilot in VS Code. So viel schafft man in 22 Minuten für die Pflicht-Abschnitte (1, 2, 4, 7, 8, 10). Die optionalen Abschnitte sind hier auch gefüllt, damit ihr seht, was gemeint ist.

## 1. Ticket-Standard (Definition of Ready) · Pflicht

| Frage | Entscheidung |
|---|---|
| Wo stehen die Akzeptanzkriterien? | Jira-Feld „Akzeptanzkriterien“, je Zeile ein prüfbares Kriterium (`AC1: …`) |
| Pflichtfeld? Wer stellt die Vorlage ein? | Pflicht beim Übergang nach „Ready“. Der Jira-Admin des Projekts stellt es ein, die PO pflegt den Inhalt |
| Wie liest `/spec` das Ticket? | `acli jira workitem view BOOK-123 --fields '*all' --json`. Rückfall bei SSO-Problemen: `tickets/BOOK-123.md`, steht in `.git/info/exclude` |

## 2. Spec-Format und Freigabe · Pflicht

| Frage | Entscheidung |
|---|---|
| Ab welcher Größe ist eine Spec Pflicht? | ab 1 Tag Aufwand, und immer bei Flyway-Migration oder Änderung an `api/openapi.yaml` |
| Wer gibt frei? | Die Person, die `/spec` gestartet hat, liest und gibt frei (`Approved-by`). Zusätzlich reviewt eine zweite Person die Spec im MR, bevor `/code` startet |
| Wo? | Kopfzeile `Status: approved  ·  Approved-by: <Name>, <Datum>` in `specs/<slug>.md`, committet. Dann ein eigener Draft-MR nur mit der Spec, den die zweite Person im GitLab-MR approvt |
| `/code` startet erst nach Freigabe: ja / nein | ja. Der `code`-Skill prüft die Kopfzeile |

## 3. Definition of Done · optional, zu Hause

- [x] `/verify` sagt **Pass**: alle Kriterien `met`, Gates grün, kein blockierendes Finding
- [x] Bericht `specs/<slug>.verification.md` hängt am MR
- [x] Menschliches Review des MR durch: eine Person aus `CODEOWNERS` für die geänderten Pfade
- [x] Weiteres: Jira-Ticket steht auf „In Review“ mit Link auf den MR. Migration hat einen Test für alte Daten

## 4. Wer prüft was · Pflicht

| Ebene | Was genau (Befehle, Regeln) | Pflicht? |
|---|---|---|
| **Hook** (lokal, deterministisch, Sekunden) | Guard (`file-guard.sh`, PostToolUse): Änderung unter `backend/src/main/resources/db/migration/` fährt `./gradlew :backend:test --tests '*Migration*'` (ca. 40 s). Stop-Hook: `./gradlew :backend:spotlessCheck` und `npm --prefix bff run lint` | ja, über `.claude/settings.json` im Repo. Copilot-Nutzer: derselbe Guard als `pre-commit` |
| **CI** (dieselben Gates, Pflicht vor dem Merge, auch für Menschen) | `.gitlab-ci.yml`: `./gradlew spotlessCheck test`, `npm --prefix bff ci`, `npm --prefix bff run lint`, `npm --prefix bff test`. Job `migration-guard` mit `rules: changes:` auf den Migrationsordner. „Pipelines must succeed“ ist an | ja |
| **Mensch** (Fachlichkeit, Architektur, passt es zur Spec) | Spec-Freigabe vor dem Code. MR-Review: passt es zur Spec, ist die Migration rückwärtskompatibel, bleibt die API kompatibel | ja |

Die eine Regel, die bei uns immer bricht und in einen Hook gehört: Eine Flyway-Migration wird geändert oder ohne Test für Bestandsdaten angelegt.

## 5. Leitplanken: was der Agent nicht darf · optional, zu Hause

| Ebene | Inhalt |
|---|---|
| `permissions.deny` im Repo | `Read(./.env)`, `Read(./.env.*)`, `Read(./**/application-prod.yml)`, `Bash(git push --force*)`, `Bash(git push -f *)`, `Bash(kubectl *)`, `Bash(helm *)` |
| Allow-Liste für Gates und Git | persönlich in `.claude/settings.local.json`: `./gradlew` mit den Gate-Tasks, `npm --prefix bff` mit `run lint` und `test`, `git add`, `git commit` |
| Managed Settings bzw. Admin-Vorgaben | Plattform-Team (Ansprechperson im Dev-Tools-Kanal). Fragen: Auto-Modus erlaubt? Welche Modelle? |
| Sandbox an? Für welche Repos? | im Pilot an, Netz nur zur internen Paket-Registry und zu GitLab |
| Was der Agent nie anfasst | Prod-Zugänge, Secrets aus dem Vault, Ordner `deploy/` und die Helm-Charts |

## 6. Wem gehören die Skills · optional, zu Hause

| Frage | Entscheidung |
|---|---|
| Ort | im Repo: `.claude/skills/`, `.claude/agents/`, `.claude/hooks/`, `.claude/settings.json`. Spiegel `.github/skills/` für Copilot in VS Code |
| Owner | `CODEOWNERS`: `/.claude/ @tech-lead @dev-a` und `/.github/skills/ @tech-lead @dev-a` |
| Änderungen nur per MR: ja / nein | ja |
| Mehrere Repos: kopieren oder internes Plugin bzw. Marketplace? | im Pilot kopieren. Nach der Retro prüfen, ob ein internes Plugin lohnt |
| Wer pflegt `AGENTS.md`? Wann wird aufgeräumt? | wer eine neue Regel einführt, trägt sie ein. Aufräumen in jeder Retro, Ziel unter 60 Zeilen |

## 7. Pilot mit drei Tickets · Pflicht

| # | Ticket | Größe | Wer | Bis |
|---|---|---|---|---|
| 1 | BOOK-1412 Storno-Grund als Pflichtfeld im Storno-Endpunkt | S, 1 Tag | Dev A | 27.11. |
| 2 | BOOK-1420 Filter nach Zahlungsstatus in der Buchungsliste (`bff/`) | M, 2 Tage | Dev B | 03.12. |
| 3 | BOOK-1433 Neue Spalte `cancelled_by` mit Flyway-Migration | M, 1,5 Tage | Dev A und Dev C | 10.12. |

Kleine, echte Tickets, fachlich klar, nicht im sicherheitskritischsten Teil. Ticket 3 testet bewusst den Guard.

## 8. Messgrößen (vorher Baseline erheben) · Pflicht

| Messgröße | Wie gemessen (Quelle) | Baseline heute | Nach dem Pilot |
|---|---|---|---|
| Durchlaufzeit (Start bis Merge) | Jira: Zeit von „In Progress“ bis „Done“, Median der letzten 20 Tickets der Größe S und M | 4,5 Tage | |
| Review-Runden pro MR | GitLab: Anzahl Review-Runden mit Änderungswunsch pro MR, letzte 20 MRs | 2,3 | |
| Nacharbeit | Jira: Bugs mit Link „is caused by“ auf das Ticket in den 2 Wochen nach Merge | 3 von 20 | |

## 9. Retro · optional, zu Hause

Termin: 11.12.2026  ·  Wer lädt ein: Tech Lead  ·  Danach entscheiden wir: ausweiten / anpassen / stoppen

## 10. Mein erster Schritt am Montag · Pflicht

Im Daily am Montag den Pilot vorschlagen und mit dem Tech Lead das Jira-Feld „Akzeptanzkriterien“ für BOOK-1412 anlegen.

Antrag an die Teamleitung in einem Satz: Drei Pilot-Tickets bis 10.12. mit Spec-Freigabe, Guard und Verify-Bericht, gemessen an Durchlaufzeit, Review-Runden und Nacharbeit gegen die letzten 20 Tickets, Entscheidung in der Retro am 11.12.
