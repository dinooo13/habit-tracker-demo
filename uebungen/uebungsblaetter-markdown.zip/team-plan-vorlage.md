# Team-Plan: Spec-Driven Development mit Agenten

Team: ______________________  ·  Repo: ______________________  ·  Ausgefüllt von: ______________________  ·  Datum: ________

Eine Seite. Jede Zeile ist eine Entscheidung, die euch kein Skill abnimmt. Was hier entschieden ist, steht danach im Repo, nicht im Chat.

**Ausfüllen im Markdown:** diese Datei (`team-plan-vorlage.md`) aus dem Markdown-Zip (`uebungsblaetter-markdown.zip`) als `team-plan.md` lokal neben eurem Repo bzw. im eigenen Repo speichern und im Editor ausfüllen, nicht im PDF.

**Material zum Mitnehmen, kein Teil einer Übung.** Wer anfängt, füllt zuerst die Pflicht-Abschnitte 1, 2, 4, 7, 8 und 10. Die Abschnitte 3, 5, 6 und 9 sind für das erste Gespräch im Team. Ein ausgefülltes Beispiel steht auf dem Blatt „Team-Plan: Beispiel“.

## 1. Ticket-Standard (Definition of Ready) · Pflicht

| Frage | Entscheidung |
|---|---|
| Wo stehen die Akzeptanzkriterien? (Abschnitt in der Beschreibung, eigenes Feld, Vorlage) | |
| Pflichtfeld? Wer stellt die Vorlage ein? (`.github/ISSUE_TEMPLATE/`, `.gitlab/issue_templates/`, Jira-Feld) | |
| Wie liest `/spec` das Ticket? (`gh`, `glab`, `acli`, MCP, Datei) | |

## 2. Spec-Format und Freigabe · Pflicht

| Frage | Entscheidung |
|---|---|
| Ab welcher Größe ist eine Spec Pflicht? (z. B. alles über einen halben Tag, jede Schema-Änderung) | |
| Wer gibt frei? (Person, Rolle, Vier-Augen) | |
| Wo? (`Status: approved · Approved-by:` in `specs/<slug>.md` und Commit, oder MR-Review der Spec-Datei) | |
| `/code` startet erst nach Freigabe: ja / nein | |

## 3. Definition of Done · optional, zu Hause

- [ ] `/verify` sagt **Pass**: alle Kriterien `met`, Gates grün, kein blockierendes Finding
- [ ] Bericht `specs/<slug>.verification.md` hängt am MR
- [ ] Menschliches Review des MR durch: ______________________
- [ ] Weiteres: ______________________

## 4. Wer prüft was · Pflicht

| Ebene | Was genau (Befehle, Regeln) | Pflicht? |
|---|---|---|
| **Hook** (lokal, deterministisch, Sekunden) | z. B. Stop-Hook mit Lint und Unit-Tests, Guard für ______ | |
| **CI** (dieselben Gates, Pflicht vor dem Merge, auch für Menschen) | | |
| **Mensch** (Fachlichkeit, Architektur, passt es zur Spec) | | |

Die eine Regel, die bei uns immer bricht und in einen Hook gehört: ______________________

## 5. Leitplanken: was der Agent nicht darf · optional, zu Hause

| Ebene | Inhalt |
|---|---|
| `permissions.deny` im Repo (z. B. `Read(./.env)`, `Bash(git push --force*)`, Deploy-Befehle) | |
| Allow-Liste für Gates und Git (persönlich in `settings.local.json` oder geteilt) | |
| Managed Settings bzw. Admin-Vorgaben (wer ist Ansprechpartner?) | |
| Sandbox an? Für welche Repos? | |
| Was der Agent nie anfasst (Prod-Zugänge, Secrets, bestimmte Ordner) | |

## 6. Wem gehören die Skills · optional, zu Hause

| Frage | Entscheidung |
|---|---|
| Ort (`.claude/skills/`, Spiegel `.agents/skills/` für Codex, Agents, Hooks, `settings.json`) | im Repo |
| Owner (`CODEOWNERS` für `.claude/` bzw. `.agents/`) | |
| Änderungen nur per MR: ja / nein | |
| Mehrere Repos: kopieren oder internes Plugin bzw. Marketplace? | |
| Wer pflegt `AGENTS.md`? Wann wird aufgeräumt? | |

## 7. Pilot mit drei Tickets · Pflicht

| # | Ticket | Größe | Wer | Bis |
|---|---|---|---|---|
| 1 | | | | |
| 2 | | | | |
| 3 | | | | |

Kleine, echte Tickets, fachlich klar, nicht im sicherheitskritischsten Teil.

## 8. Messgrößen (vorher Baseline erheben) · Pflicht

| Messgröße | Wie gemessen (Quelle) | Baseline heute | Nach dem Pilot |
|---|---|---|---|
| Durchlaufzeit (Start bis Merge) | | | |
| Review-Runden pro MR | | | |
| Nacharbeit (Fix-Commits bzw. Bugs zum Ticket in den 2 Wochen nach Merge) | | | |

## 9. Retro · optional, zu Hause

Termin: ________  ·  Wer lädt ein: ________  ·  Danach entscheiden wir: ausweiten / anpassen / stoppen

## 10. Mein erster Schritt am Montag · Pflicht

______________________________________________________________________

Antrag an die Teamleitung in einem Satz (optional): Was, mit wie vielen Tickets, bis wann, woran gemessen?

______________________________________________________________________
