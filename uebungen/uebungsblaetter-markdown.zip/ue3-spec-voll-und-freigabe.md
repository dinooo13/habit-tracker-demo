# Ü3 Spec-Skill ausbauen, Spec schreiben, selbst freigeben

**Tag 1 · Mittwoch 18.11., am späten Nachmittag · Zeitbox 65 Minuten**

## Ziel

Euer Spec-Skill wird v2: Er liest das Ticket selbst, lässt einen Subagenten den Code kartieren, liest die ADRs, fragt nach und hält an. Dann gebt ihr die Spec selbst frei. Der Agent hat sie geschrieben, ihr habt `/spec` gestartet: Ihr seid der erste Mensch, der sie wirklich liest und verantwortet. Die Freigabe ist also ein echter Review des Agenten-Ergebnisses, mit der Checkliste unten. Sie steht danach im Repo, nicht nur im Chat.

**Done, wenn …**

- [ ] der Skill fünf Schritte hat: **1** Ticket per CLI (oder aus `tickets/<KEY>.md`) lesen, **2** Recherche mit `AGENTS.md`, ADRs und einem read-only Subagenten, **3** Rückfragen in einer Runde, **4** Spec schreiben mit Kopfzeile `Status: draft  ·  Approved-by: –`, **5** anhalten,
- [ ] `/spec <ticket>` in einer neuen Session eine Spec unter `specs/<slug>.md` geschrieben hat,
- [ ] ihr die Spec mit der Spec-Review-Checkliste (unten) gelesen und eure Anmerkungen vom Agenten habt einarbeiten lassen,
- [ ] die Kopfzeile `Status: approved  ·  Approved-by: <eigener Name>, 2026-11-18` lautet und **nur die Spec** als `docs(spec): approve <slug>` committet ist.

Wer mag, zeigt die Spec kurz jemandem im Raum. Das ist freiwillig und kein Teil von Done.

## Zeitplan

| Min. | Was |
|---|---|
| 0-5 | Blatt lesen |
| 5-20 | Skill v2 bauen (Weg B: eure v1 um die Bausteine aus Hilfe 2 erweitern, wörtlich übernehmen ist ok; Weg A: Vorlage übernehmen und anpassen). **Spätestens Minute 20 läuft `/spec`.** |
| 20-37 | Neue Session, `/spec <ticket>`, Rückfragen beantworten. Im Firmen-Repo braucht die Recherche oft 5-10 Minuten. |
| 37-52 | Spec-Review: eigene Spec mit der Checkliste lesen, 3-5 Anmerkungen, vom Agenten einarbeiten lassen |
| 52-60 | Freigabe in die Kopfzeile, committen |
| 60-65 | Debrief-Person notiert den Debrief-Beitrag und postet ihn in den globalen Chat, aus dem Raum oder gleich nach der Rückkehr |

Der Kursleiter kommt reihum in die Räume. Wer hängt: erst die gestuften Hilfen unten, dann die Gruppe, dann dem Kursleiter im globalen Chat schreiben (Raum und ein Satz).

Dauert die Recherche länger? Lauf weiterlaufen lassen und in der Wartezeit die Checkliste schon einmal lesen.

## Weg A: euer Repo

Realistischer Enterprise-Weg: den Spec-Skill aus der Vorlage übernehmen und mit eurer v1 vergleichen.

1. Vorlage übernehmen (eure v1 ist in Ü2 committet, ihr verliert nichts):

   ```bash
   cp ../rheinwerk-starter-skills/.claude/skills/spec/SKILL.md \
     .claude/skills/spec/SKILL.md
   grep -n ANPASSEN .claude/skills/spec/SKILL.md
   ```

2. Unter `## Settings` jede `<ANPASSEN>`-Stelle füllen und die nicht passenden Zeilen löschen:

   | System | Ticket lesen |
   |---|---|
   | GitHub | `gh issue view <n> --json number,title,body,comments` |
   | GitLab | `glab issue view <n> --comments` |
   | Jira | `acli jira workitem view <KEY-123> --fields '*all' --json` (ohne `'*all'` fehlen Kommentare und Custom Fields) |
   | CLI geht im Firmennetz nicht | `Read the file tickets/<KEY>.md` (Ticket-Text dort hineinkopieren, siehe Ü0) |

   Dazu Gates, Dev-URL bzw. Port und den Freigabe-Modus (Standard: Kopfzeile in der Spec und Commit `docs(spec): approve <slug>`).
3. Vergleichen, was die Vorlage anders macht als eure v1:

   ```bash
   git diff HEAD -- .claude/skills/spec/SKILL.md
   ```

   Übernehmt, was bei euch besser war (z. B. eure Rückfragen-Regeln).
4. Neue Session, `/spec <KEY-123>` bzw. `/spec <n>`. Rückfragen beantworten.
5. Review und Freigabe wie unten, mit eurem Namen. **Vertraulichkeit:** Zeigt ihr die Spec freiwillig jemandem im Raum, dann nur, was ihr zeigen dürft. Oft reichen Context, Akzeptanzkriterien, Non-goals und Tasks ohne Dateipfade.
6. Ob im Firmen-Repo eure Freigabe reicht oder zusätzlich ein MR-Review der Spec nötig ist, legt ihr im Team fest (Team-Plan-Vorlage, Abschnitt 2). Gepusht wird nur, wenn euer Team-Verfahren das vorsieht.

## Weg B: Demo-Fork

1. Auf `seminar/kategorien` eure v1 zu v2 ausbauen. Die fünf Bausteine:
   - **Ticket lesen:** Ist das Argument eine Zahl (`1` oder `#1`), liest der Skill es mit `gh issue view <n> --json number,title,body,comments`.
   - **Recherche:** zuerst `AGENTS.md`, dann `docs/adr/README.md` und die passenden ADRs. Die Codesuche geht an einen read-only Subagenten, der eine Karte `pfad:zeile - warum` liefert (höchstens ca. 40 Zeilen). Danach die Dateien aus der Karte selbst öffnen.
   - **Rückfragen:** eine Runde, 3-7 Fragen, je 2-4 Optionen mit Empfehlung zuerst. Nichts fragen, was Code oder ADR schon beantworten.
   - **Spec:** feste Abschnitte (Context, Research, Requirements, Non-goals, Tasks, Acceptance criteria, Verification plan) und die Kopfzeile `Issue: #1  ·  Status: draft  ·  Approved-by: –`.
   - **Stopp und Freigabe:** anhalten. Nur ein Mensch gibt frei. Dann setzt der Skill `Status: approved  ·  Approved-by: <name>, <YYYY-MM-DD>` und committet nur die Spec als `docs(spec): approve <slug>`.
2. Commit des Skills:

   ```bash
   git add .claude/skills && git commit -m "feat(skills): spec skill v2"
   ```

3. Neue Session:

   ```text
   /spec 1
   ```

4. **Rückfrage 1 (Kategorien) mit „feste Liste“ beantworten.** Die Musterlösung ab Ü4 nutzt eine feste Liste (`HABIT_CATEGORIES`). Die anderen Fragen beantwortet ihr nach eigenem Urteil.
5. Review und Freigabe wie unten, mit eurem Namen.

## Spec-Review-Checkliste (vor der Freigabe)

Lest eure Spec, als hättet ihr sie nicht geschrieben. Ihr habt sie ja auch nicht geschrieben, der Agent war es. Ca. 8 Minuten. Jede Zeile ist eine Ja/Nein-Frage. Jedes „Nein“ wird eine Anmerkung.

- [ ] **Ticket abgedeckt:** Jedes Akzeptanzkriterium des Tickets taucht in der Spec auf.
- [ ] **Akzeptanzkriterien prüfbar:** beobachtbares Verhalten, das ein Test oder ein Klick zeigt. Kein „funktioniert gut“, kein „ist performant“.
- [ ] **Verifikationsplan:** Jedes Kriterium hat dort eine Zeile (Unit, E2E oder Browser).
- [ ] **Schwere Fälle:** leere Listen, aktiver Filter, Neuladen, alte Daten und Backups, Fehler, mobile Breite. Was fehlt?
- [ ] **Non-goals:** Steht da, was ausdrücklich nicht geändert wird?
- [ ] **Berührte Stellen gefunden:** Die Research-Tabelle nennt echte Pfade. Stichprobe: zwei Pfade selbst öffnen. Fehlt eine Stelle, die ihr aus Ü1 kennt?
- [ ] **ADRs und harte Regeln:** Verstößt die Spec gegen eine? Braucht sie ein neues ADR (Datenschema, Persistenz, Kern-Abhängigkeit)? Wie migrieren alte Daten?
- [ ] **Offene Fragen geklärt:** Die Entscheidungen stehen in der Spec. Kein „TBD“, kein „klären wir später“.
- [ ] **Tasks klein genug:** Jeder Task ist ein Commit, einzeln testbar, mit genannten Dateien.
- [ ] **Kurz:** In fünf Minuten lesbar.

Ergebnis: **freigeben**, **nach kleinen Änderungen freigeben** oder **zurück an `/spec`**. Die Anmerkungen schreibt ihr in dieselbe Session, der Agent arbeitet sie ein. Danach lest ihr die geänderten Stellen noch einmal.

## Freigabe und Commit

Seid ihr mit der Spec einverstanden, schreibt ihr in **dieselbe Session**, in der `/spec` lief:

```text
Passt, freigegeben, <Vorname Nachname>
```

Euer eigener Name: Ab jetzt verantwortet ihr die Spec.

Der Skill setzt die Kopfzeile und committet nur die Spec. Prüfen:

```bash
grep -n "Status:" specs/*.md
git log --oneline -1
```

Session schon zu? Von Hand freigeben und committen (Name und Slug einsetzen):

```bash
NAME="Vorname Nachname"
HDR="Status: approved  ·  Approved-by: $NAME, 2026-11-18"
perl -pi -e "s/Status: draft.*/$HDR/" specs/<slug>.md
git add specs/<slug>.md && git commit -m "docs(spec): approve <slug>"
```

## Pro Tool

| Tool | Read-only Subagent für die Recherche | Rückfragen | Hinweis |
|---|---|---|---|
| Claude Code | eingebauter **Explore** (Agent-Tool, read-only, eigenes Context Window) | `AskUserQuestion` zeigt Optionen zum Anklicken | Explore startet ohne `CLAUDE.md`, darum liest der Skill `AGENTS.md` und ADRs selbst |
| Codex | eingebauter **explorer**. Codex startet Subagenten, wenn ihr, `AGENTS.md` oder der Skill es ausdrücklich verlangt, also im Skill: „Spawn the explorer subagent …“ | im Chat | Skill nach jeder Änderung spiegeln (Kasten unter der Tabelle) |
| Cursor | eingebauter **Explore**-Subagent | im Chat | Terminal-Befehle (`gh`) müssen erlaubt sein |
| Copilot | VS Code: Subagenten laufen über eigene Agents (`.github/agents/*.agent.md`, Tools auf Lesen beschränken). CLI: siehe Doku zu Custom Agents | im Chat | Gibt es keinen Subagenten, recherchiert der Skill selbst. Das geht, kostet aber Context Window. Formuliert den Schritt neutral: „Delegate the code search to a read-only subagent if your tool has one.“ VS Code: Skill nach jeder Änderung spiegeln (Kasten unter der Tabelle) |

Skill nach jeder Änderung spiegeln (im Repo-Ordner), nur den Kasten für euer Tool:

```bash
# Codex
mkdir -p .agents && cp -R .claude/skills .agents/
```

```bash
# Copilot in VS Code
mkdir -p .github && cp -R .claude/skills .github/
```

Die Vorlage in Weg A nennt Explore und explorer schon. Für alle gilt: `gh`, `glab` und `acli` laufen als Terminal-Befehl. Bei Copilot Business und Enterprise muss der Admin Terminal-Befehle im Agent-Modus erlauben.

## Gestufte Hilfen

<details>
<summary>Hilfe 1: Denkanstoß</summary>

- Warum ein Subagent? Die Codesuche liest Dutzende Dateien. Im Hauptkontext würden sie das Context Window füllen, und die Rückfragen kämen aus der „Dumb Zone“. Der Subagent gibt nur die Karte zurück.
- Warum „Stopp“? Ohne ihn schreibt der Agent nach der Spec direkt Code, und die Freigabe ist Makulatur.
- Warum gebt ihr selbst frei? Der Agent hat die Spec geschrieben, ihr lest sie als erster Mensch. Mit eurem Namen in `Approved-by` sagt ihr: geprüft, ich stehe dafür ein.
- Warum die Kopfzeile? `/code` prüft in Ü4 genau diese Zeile. Steht dort `draft`, fragt er nach.

</details>

<details>
<summary>Hilfe 2: Bausteine zum Kopieren (Schritt 1 und 2)</summary>

````markdown
## 1. Read the task

- If the argument is an issue number (`42` or `#42`), read it with
  `gh issue view <n> --json number,title,body,comments`: title, body and all
  comments. Its acceptance criteria are the starting point, not the limit.
- Otherwise the argument is the task itself. With no argument, ask and stop.

## 2. Research

- Read `AGENTS.md` first. Then the ADR index `docs/adr/README.md` and every
  accepted ADR the task touches. A structural change needs a **new ADR**.
- Delegate the code search to a read-only subagent (Claude Code: Explore, Codex:
  explorer). Ask for a compact map, at most about 40 lines, of every affected file
  as `path:line - why`, plus the existing tests. Ask it to check side effects that
  are easy to miss: schemas and migrations, import and export, demo data, test seeds.
- Open the files the map names before you rely on them. The subagent can be wrong.
````

Und der Schluss (Schritt 5):

````markdown
## 5. Stop for approval

Show the spec path, a five-line summary and your decisions. Then **stop**.
Only a human approves. When they do, set the header to
`Status: approved  ·  Approved-by: <name>, <YYYY-MM-DD>` and commit only the spec:
`docs(spec): approve <slug>`. Never set `approved` on your own.
````

</details>

<details>
<summary>Hilfe 3: Musterlösung ansehen</summary>

```bash
git diff origin/stufe/01-spec-starter origin/stufe/02-spec-voll \
  -- .claude/skills/spec/SKILL.md
git show origin/stufe/02-spec-voll:specs/kategorien.md
```

Achtet in der Muster-Spec auf die Research-Tabelle (12 Stellen, u. a. `merge-app-data.ts`, `ai-prompts.ts`, die Test-Literale), die Entscheidung „Fixed default category Other“ und AC5 zum Leerzustand.

Weg A: `git show origin/main:.claude/skills/spec/SKILL.md` im Clone der Vorlage, bzw. die Datei, die ihr in Schritt 1 kopiert habt.

</details>

## Rückfall

Weg B, auf `seminar/kategorien`. **Skill v2 fehlt oder läuft nicht:**

```bash
git checkout origin/stufe/02-spec-voll -- .claude/skills/spec
git commit -m "feat(skills): spec skill v2"
```

Eure `AGENTS.md` bleibt. Fehlt sie auch, holt ihr sie dazu:

```bash
git checkout origin/stufe/02-spec-voll -- AGENTS.md
```

**Spec fehlt:** Muster-Spec holen, mit der Checkliste lesen, mit eurem Namen freigeben, committen.

```bash
NAME="Vorname Nachname"
mkdir -p specs
HDR="Status: approved  ·  Approved-by: $NAME, $(date +%F)"
git show origin/stufe/02-spec-voll:specs/kategorien.md \
  | sed "s/Status: draft.*/$HDR/" > specs/kategorien.md
git add specs/kategorien.md && git commit -m "docs(spec): approve kategorien"
grep -n "Status:" specs/kategorien.md
```

Codex danach spiegeln bzw. Copilot in VS Code, falls nötig (nur den Kasten für euer Tool):

```bash
# Codex
mkdir -p .agents && cp -R .claude/skills .agents/
```

```bash
# Copilot in VS Code
mkdir -p .github && cp -R .claude/skills .github/
```

Weg A: Minimum für Ü4 ist eine freigegebene Spec im Repo. Habt ihr keine eigene geschafft, nehmt die Vorlage aus Schritt 1 unverändert, füllt nur den Ticket-Befehl und lasst sie einmal laufen. Lesen und freigeben könnt ihr bis morgen früh selbst.

## Bonus für Schnelle

- Eigene Spec mit der Muster-Spec vergleichen: Was steht dort, das bei euch fehlt (Research-Tabelle, Leerzustand, alte Daten)? Weg B und Weg A mit Fork:

  ```bash
  git show origin/stufe/02-spec-voll:specs/kategorien.md
  ```

  Weg A ohne Fork im Browser:
  <https://github.com/dinooo13/habit-tracker-demo/blob/stufe/02-spec-voll/specs/kategorien.md>

- v1 gegen v2 vergleichen: `diff ../spec-v1/<slug>.md specs/<slug>.md`. Was hat die Recherche gefunden, das v1 fehlte?
- Weg B: Issue #2 (Wochentags-Karte) als zweite Runde: `/spec 2` auf einem eigenen Branch mit euren Skills:

  ```bash
  git switch --no-track -c seminar/wochentage origin/main
  git checkout seminar/kategorien -- AGENTS.md .claude
  ```

- Ticket-Vorlage mit Pflichtfeld Akzeptanzkriterien ansehen (Weg A: `templates/` in der Vorlage):

  ```bash
  git show origin/stufe/02-spec-voll:.github/ISSUE_TEMPLATE/feature_request.yml
  ```

### Bonus BMad: dieselbe Spec mit `bmad-build`

Nur, wenn eure eigene Spec freigegeben und committet ist. Ihr lasst dasselbe Ticket einmal von [BMad Method](https://github.com/bmad-code-org/BMAD-METHOD/blob/V6.12/docs/build/build-a-change.md) 6.12.4 planen, bis zum **CHECKPOINT 1**, und vergleicht die Spec mit eurer eigenen. BMad ist hier ein Vergleich, kein Ersatz:

- **Eure Freigabe bleibt** `Approved-by: <eigener Name>` in der Kopfzeile und der Commit `docs(spec): approve <slug>`. Daran ändert der Bonus nichts.
- **BMad gibt nur im Chat frei.** Am CHECKPOINT 1 wählt ihr „Approve and stop“, Build setzt `status: 'ready-for-dev'`. Wer freigegeben hat und wann, steht nirgends, und committet wird nichts.

Im Test (Demo-Repo, Claude Code, Sonnet): zwei Rückfragen. Voraussetzungen für Variante 2 stehen in der Vorab-Info (Node ab 20.12, `uv`, Zugriff auf die npm-Registry).

**Variante 1, ohne Installation (ca. 5 Minuten).** Die fertige BMad-Spec zu Issue #1 aus dem Demo-Repo lesen und mit eurer vergleichen. Im Fork:

```bash
git fetch origin
S=_bmad-output/implementation-artifacts/spec-gh-1-habit-categories-filter.md
git show "origin/bmad/03-spec-bereit:$S"
```

Meldet Git „invalid object name“, fehlen im Fork die `bmad/*`-Branches (Fork mit „Copy the main branch only“). Einmal nachschieben, wie die Stufen in Ü0:

```bash
git remote add upstream \
  https://github.com/dinooo13/habit-tracker-demo.git 2>/dev/null
git fetch upstream
git push origin 'refs/remotes/upstream/bmad/*:refs/heads/bmad/*'
git fetch origin
```

Weg A ohne Fork im Browser: <https://github.com/dinooo13/habit-tracker-demo/blob/bmad/03-spec-bereit/_bmad-output/implementation-artifacts/spec-gh-1-habit-categories-filter.md>

**Variante 2, selbst erzeugen (15-20 Minuten).** Immer in einem **Wegwerf-Worktree**, nie im Übungs-Branch: BMad bringt Hunderte Dateien mit (nur das Modul `bmm` gut 230, mit `tea` und `bmb` wie im Demo-Repo gut 1.000).

Weg B: Der Demo-Branch `bmad/02-installiert` hat BMad 6.12.4, die `.gitignore`-Zeilen und das Team-Override (volle Spec, nie One-Shot) schon committet. Im Fork-Ordner:

```bash
git fetch origin
git worktree add -b wegwerf/kategorien-bmad ../habit-bmad \
  origin/bmad/02-installiert
cd ../habit-bmad
printf '%s\n' '[core]' 'user_name = "Vorname Nachname"' \
  'communication_language = "German"' > _bmad/custom/config.user.toml
git status --short   # leer
```

Die letzte Datei ist persönlich und von Git ignoriert. Ohne sie antwortet Build auf Englisch.

Weg A: Worktree aus eurem Basis-Branch, nicht aus dem Übungs-Branch, sonst liest Build eure Spec mit. BMad installieren (interaktiv: Modul `bmm`, euer Tool, Name, Sprache Deutsch):

```bash
git worktree add -b wegwerf/bmad ../mein-repo-bmad origin/main
cd ../mein-repo-bmad
npx bmad-method@6.12.4 install
```

Dann persönliche Dateien ignorieren, das Team-Override anlegen und alles committen (nur in diesem Wegwerf-Branch, nie pushen):

```bash
printf '%s\n' '' '# BMad: personal install answers' \
  _bmad/config.user.toml _bmad/core/config.yaml _bmad/bmm/config.yaml \
  >> .gitignore
mkdir -p _bmad/custom
cat > _bmad/custom/bmad-build.toml <<'TOML'
[workflow]
persistent_facts = [
  """Team rule: always write the full spec (route: dispatch) and HALT at \
  CHECKPOINT 1 for human approval. Never take the oneshot route, even for \
  small changes.""",
]
TOML
git add -A && git commit -q -m "chore: add BMad 6.12.4 (Wegwerf)"
git status --short   # leer
```

Dann, Weg A und B:

1. **Frische Session** im Wegwerf-Worktree (Cursor, Copilot: Worktree als eigenes Fenster öffnen).
2. **Build starten** mit dem Ticket-Text. Weg B: Text aus `gh issue view 1` einfügen.

   ```text
   /bmad-build GitHub Issue #1: Kategorien für Habits mit Filter.
   <Beschreibung und Akzeptanzkriterien einfügen>
   ```

   Codex: `$bmad-build …`. Fragt euer Tool, ob es `uv run …` ausführen darf: erlauben.
3. **Rückfragen mit dem Inhalt beantworten**, nicht nur mit dem Buchstaben, z. B. `1: feste Liste (Health, Learning, Work). 2: kein eigener Filter.` Die Buchstaben wechseln zwischen Läufen.
4. **CHECKPOINT 1:** Build zeigt Pfad, Zusammenfassung und drei Optionen. Tippt wörtlich **`Approve and stop`**. Nicht „Approve and continue“, das baut sofort Code.
5. **Vergleichen.** Die Spec liegt unter `_bmad-output/implementation-artifacts/spec-<slug>.md`. Legt sie neben eure:

   | Eure Spec | BMad-Spec |
   |---|---|
   | Research-Tabelle | `## Code Map` |
   | Akzeptanzkriterien, Verifikationsplan | `## Tasks & Acceptance`, `## Verification` |
   | Schwere Fälle in den Kriterien | `## I/O & Edge-Case Matrix` |
   | Non-goals | `## Boundaries & Constraints`, *Never* |
   | Kopfzeile `Approved-by` | Frontmatter `status: 'ready-for-dev'`, kein Name |

   Fragen: Welche Stelle im Code fand nur einer von beiden? Welche Fälle stehen nur in einer Spec? Was hat Build ohne Rückfrage selbst entschieden, und hättet ihr das gewollt? Wer hat mehr gefragt, euer `/spec` oder Build?
6. **Aufräumen.** Wer die BMad-Spec behalten will, kopiert sie vorher aus dem Worktree heraus. Dann im Haupt-Checkout:

   ```bash
   git worktree remove --force ../habit-bmad
   git branch -D wegwerf/kategorien-bmad
   ```

   Weg A entsprechend `../mein-repo-bmad` und `wegwerf/bmad`. Euer Übungs-Branch ist unberührt.

<details>
<summary>Fallstricke BMad (aus den Testläufen)</summary>

- **Nach der Installation committen.** Ein neuer Build hält bei schmutzigem Tree an („Der Arbeitsbaum ist nicht sauber“). Vorsicht umgekehrt: Liegt schon eine Spec auf `ready-for-dev`, prüft Build den Tree nicht und nimmt untracked Dateien in seinen Commit.
- **Persönliche Konfig nicht committen:** `_bmad/config.user.toml`, `_bmad/core/config.yaml`, `_bmad/bmm/config.yaml` enthalten Name und Sprache. Ohne `config.user.toml` (z. B. auf `bmad/02-installiert`) antwortet Build auf Englisch. Abhilfe: `_bmad/custom/config.user.toml` wie oben.
- **Team-Override anlegen:** `_bmad/custom/bmad-build.toml` mit `persistent_facts` „volle Spec, nie One-Shot“. Sonst nimmt Build bei kleinen Änderungen den One-Shot-Weg: kurze Spec mit `route: 'oneshot'`, kein CHECKPOINT, er programmiert sofort. Dann abbrechen (Esc bzw. Ctrl-C) und im Worktree `git restore . && git clean -fd`. Ein Override wirkt erst in einer neuen Session.
- **Rückfragen nach Inhalt beantworten,** nicht per Buchstabe.
- **Codex, Cursor, Copilot:** Der Installer legt die Skills mit `--tools codex`, `cursor` bzw. `github-copilot` unter `.agents/skills/` ab. Auf `bmad/02-installiert` liegen sie nur unter `.claude/skills/`: Codex braucht `mkdir -p .agents && cp -R .claude/skills .agents/`, danach committen. Copilot in VS Code liest laut Doku `.github/skills/`. Skill-Test: neuer Chat, `/` tippen, `bmad-build` muss erscheinen, sonst `mkdir -p .github/skills && cp -R .agents/skills/bmad-* .github/skills/` (bzw. aus `.claude/skills/`) und committen. **Agentenläufe in Codex, Cursor und Copilot sind nicht getestet.**
- **`npx skills add …` nicht ausführen,** auch wenn der Installer es am Ende empfiehlt. Das holt v7-Skills mit denselben Namen. Schon passiert: Worktree wegwerfen und neu anlegen.
- **Firmennetz:** `npx` braucht die npm-Registry, `uv` lädt beim ersten Lauf ein Python. Geht das nicht: Variante 1.

</details>

## Für den Debrief

Leitfrage: **Was hat die Recherche gefunden, das im Ticket nicht stand? Was habt ihr vor der Freigabe an der Spec geändert?**

- Debrief-Beitrag (Debrief-Person, in den globalen Chat): eine Stelle, die die Recherche gefunden hat, eine Änderung vor der Freigabe, und eine Frage.
- Im Plenum zeigen ein, zwei Personen, die der Kursleiter beim Rundgang gefragt hat, ihre Spec (Weg A ggf. nur Akzeptanzkriterien). Der Kursleiter stellt die Fragen und zeigt die Muster-Spec aus Stufe 2 mit der Kopfzeile `Approved-by`.
- Wer heute nicht freigegeben hat: bis morgen früh nachholen oder morgen früh den Rückfall nehmen.
