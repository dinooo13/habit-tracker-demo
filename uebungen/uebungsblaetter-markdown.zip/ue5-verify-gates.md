# Ü5 Verify v1: Gates, E2E, Beleg pro Kriterium

**Tag 2 · Donnerstag 19.11., vor dem Mittag · Zeitbox 60 Minuten**

## Ziel

Ihr baut die ersten drei Schichten von `/verify`: alle Gates inkl. E2E, ein Beleg aus Code und Test für jedes Akzeptanzkriterium, ein Bericht mit Gesamturteil und Fix-Liste. Verify prüft und baut nicht. Befunde gehen über die Fix-Liste zurück an `/code`: pro Punkt ein roter Test, ein Fix, ein Commit.

**Done, wenn …**

- [ ] `.claude/skills/verify/SKILL.md` existiert, mit `disable-model-invocation: true` und der Regel „You check, you do not build“,
- [ ] der Skill alle Gates fährt, inkl. E2E (Weg B: `PORT=3110 E2E_PORT=3110 npm run test:e2e`), und Ergebnis, Testanzahl und Dauer festhält,
- [ ] der Skill für **jedes** Akzeptanzkriterium `met`, `partly met` oder `not met` mit Datei und Testname als Beleg festhält (ohne Test höchstens `partly met`),
- [ ] der Bericht mit `## Fix list` endet: jedes nicht erfüllte Kriterium und jedes rote Gate als Checkbox mit Quelle, sonst `none`,
- [ ] euer `code`-Skill einen Absatz „Fix list“ hat: offene Punkte abarbeiten, Test zuerst, ein Commit pro Punkt, höchstens zwei Runden,
- [ ] `/verify specs/<slug>.md` in einer neuen Session gelaufen ist und `specs/<slug>.verification.md` mit dem Gesamturteil **Pass** oder **Issues found** committet hat.

„Issues found“ ist ein gutes Ergebnis. Dann hat Verify seine Arbeit getan.

## Zeitplan

| Min. | Was |
|---|---|
| 0-5 | Blatt lesen, Stand prüfen (`git log --oneline -3`, Gates einmal von Hand) |
| 5-22 | `verify`-Skill schreiben: Laden, Spec gegen Implementierung, Gates, Bericht mit Fix-Liste |
| 22-27 | `code`-Skill um „Fix list“ ergänzen (Gerüst in Hilfe 2), committen |
| 27-30 | Dev-Server stoppen (`lsof -i :3110` muss leer sein), neue Session, `/verify specs/<slug>.md` |
| 30-46 | Lauf beobachten. Währenddessen im Raum den Bericht von `kurs/verify-rot` lesen (Hilfe 3) |
| 46-55 | Eigenen Bericht lesen: Stimmen die Belege? Ist „met“ wirklich belegt? Steht jeder offene Punkt in der Fix-Liste? |
| 55-60 | Debrief-Person notiert den Debrief-Beitrag und postet ihn in den globalen Chat, aus dem Raum oder gleich nach der Rückkehr |

Der Kursleiter kommt reihum in die Räume. Wer hängt: erst die gestuften Hilfen unten, dann die Gruppe, dann dem Kursleiter im globalen Chat schreiben (Raum und ein Satz).

## Weg A: euer Repo

1. Skill aus der Vorlage übernehmen:

   ```bash
   mkdir -p .claude/skills/verify
   cp ../rheinwerk-starter-skills/.claude/skills/verify/SKILL.md \
     .claude/skills/verify/SKILL.md
   grep -n ANPASSEN .claude/skills/verify/SKILL.md
   ```

2. Für v1 nur **Load, Spec against implementation, Gates, Report** behalten. Die Abschnitte „Fresh review“, „Browser walk“ und „Draft PR/MR“ löscht ihr vorerst. Review und Browser walk kommen in Ü6 zurück, den Draft-PR/MR probiert ihr zu Hause. Passt dazu die Regel für das Gesamturteil und die Berichts-Vorlage an (nur Kriterien und Gates). Ans Ende der Vorlage kommt `## Fix list` (Gerüst in Hilfe 2).
3. Im `code`-Skill aus Ü4 den Absatz „Fix list“ aus Hilfe 2 ergänzen.
4. Settings füllen: Basis-Branch, Gates. **Keine E2E-Tests?** Dann stehen nur die schnellen Gates drin, und der Bericht schreibt unter „Not verified“, was ein E2E-Test geprüft hätte. **E2E nur in der Pipeline?** Ebenso, und als Notiz für zu Hause (mit `--pr` wartet Verify auf die Pipeline).
5. Committen, neue Session, `/verify specs/<slug>.md`.

## Weg B: Demo-Fork

1. Auf eurem Branch (`seminar/kategorien` bzw. `seminar/ab-ue5`) den Skill schreiben (Gerüst in Hilfe 2). Die drei Schichten:
   - **Gates:** `npm run lint`, `npm run typecheck`, `npm test`. Rot ist ein blockierender Befund. Nie einen roten Test so lange wiederholen, bis er zufällig grün ist.
   - **E2E:** der Befehl im Kasten. `PORT` ist der Port der App, `E2E_PORT` der, auf den Playwright wartet. Nie 3000 (Playwright-Default). Läuft schon ein Dev-Server auf 3110, nimmt Playwright den statt des Builds, also vorher stoppen.

     ```bash
     PORT=3110 E2E_PORT=3110 npm run test:e2e
     ```

   - **Beleg pro Kriterium:** für jedes AC und jede Must-Anforderung Code und Test finden. Ohne Test höchstens `partly met`. Scope Creep melden.
   - **Fix-Liste:** am Ende des Berichts `## Fix list`, jeder offene Punkt eine Checkbox mit Quelle, z. B. `- [ ] F2 (Gate) npm run typecheck rot`. Alles grün: `none`.
2. Den `code`-Skill um den Absatz „Fix list“ aus Hilfe 2 erweitern. `/code` arbeitet dann eine offene Fix-Liste ab: pro Punkt erst ein roter Test, dann der Fix, ein Commit `fix: … (F2)`, ein Haken. Maßstab bleibt die Spec.
3. Committen und Port prüfen:

   ```bash
   git add .claude/skills && git commit -m "feat(skills): verify v1, fix list"
   lsof -i :3110 || echo "3110 frei"
   ```

4. Neue Session:

   ```text
   /verify specs/kategorien.md
   ```

5. Bericht lesen: `cat specs/kategorien.verification.md`, Commit prüfen: `git log --oneline -1`.

## Pro Tool

| Tool | Aufruf | Hinweis |
|---|---|---|
| Claude Code | `/verify specs/kategorien.md` | Die Allow-Liste aus Ü4 enthält den E2E-Befehl. Sonst den Prompt einmal bestätigen. |
| Codex | `$verify specs/kategorien.md` (nach `cp -R .claude/skills .agents/`) | E2E startet einen Browser und einen Server auf 3110. Scheitert das in der Sandbox, im Demo-Fork über `/permissions` Full Access. |
| Cursor | `/verify specs/kategorien.md` im Agent-Chat | Langer Terminal-Befehl: Wartet, bis der Agent die Ausgabe gelesen hat, nicht abbrechen. |
| Copilot | `/verify specs/kategorien.md` im Agent-Modus bzw. in der CLI | Wie Cursor. |

`disable-model-invocation: true` ist ein Claude-Code-Feld: Der Skill startet nur, wenn ihr ihn tippt. Andere Tools ignorieren es oder werten es eigen aus, siehe Doku eures Tools.

## Gestufte Hilfen

<details>
<summary>Hilfe 1: Denkanstoß</summary>

- Warum ein eigener Skill und nicht einfach am Ende von `/code`? Wer gebaut hat, prüft gnädig. Verify startet in einer neuen Session und sieht nur Spec, Branch und Gates.
- „Met“ heißt: Es gibt Code **und** einen Test, der brechen würde, wenn das Kriterium bricht. „Der Code sieht richtig aus“ ist kein Beleg.
- Der Bericht liegt im Repo neben der Spec. Mit `--pr` (Hausaufgabe) landet er im MR.

</details>

<details>
<summary>Hilfe 2: Gerüst zum Kopieren</summary>

````markdown
---
name: verify
description: Verify a branch against its spec, run the gates, write a report.
argument-hint: "[specs/<slug>.md]"
disable-model-invocation: true
---

# Verify

Verify the implementation of: **$ARGUMENTS**

You check, you do not build. Fix nothing here. Findings go to the report,
fixes go back to `/code` through the fix list.

## Load
- Read the spec. Collect the diff:
  `git diff main...HEAD --stat`, `git log main..HEAD --oneline`.

## Spec against implementation
For every acceptance criterion and every Must requirement, find the code and the
test that prove it. Record `met`, `partly met` or `not met` with file and test name.
A criterion without a test is at most `partly met`. Flag scope creep.

## Gates
Run each, record result, test counts and duration:
<lint>, <typecheck>, <unit tests>, <e2e with a fixed free port, never 3000>
Stop a dev server on that port first. A red gate is a blocking finding.
Never rerun a failing test until it passes by luck.

## Report
Write `specs/<slug>.verification.md`:
  # Verification: <Title>
  Branch: <branch> @ <sha>  ·  Verdict: Pass | Issues found
  ## Acceptance criteria   | AC | Code + test | Result |
  ## Gates                 | Gate | Result | Duration |
  ## Not verified
  ## Fix list
  - [ ] F1 (AC3 not met) <what is missing>
  - [ ] F2 (Gate) <gate> red: <first error>
Every criterion `not met` or `partly met` and every red gate goes to the fix
list, with its source. Non-blocking findings stay in the report. Nothing open:
`none`.
Verdict is Pass only when every gate is green and every criterion is `met`.
Commit only the report: `docs(spec): add verification report for <slug>`.
````

Für den `code`-Skill, unter „Load the spec“:

```markdown
**Fix list.** If `specs/<slug>.verification.md` says `Verdict: Issues found`
and its `## Fix list` has open items, work only those, in order: a test that
shows the problem (red), then the fix (green), one commit per item
(`fix: <what> (F2)`) and tick it (`- [x]`). The spec stays the measure, no new
scope. Then suggest `/verify` again. After two fix rounds, the human decides.
```

</details>

<details>
<summary>Hilfe 3: Musterlösung ansehen</summary>

Die Musterlösung mit Fix-Liste in `verify` und `code` (enthält auch Ü4):

```bash
M=origin/seminar/ue5-fix-list
git show $M:.claude/skills/verify/SKILL.md
git diff origin/stufe/06-verify-spec-abgleich $M -- .claude/skills
```

Wie `verify` Schicht für Schicht entstand, je als Diff zur Vorstufe:

```bash
F=.claude/skills/verify/SKILL.md
git show origin/stufe/04-verify-gates:$F
git diff origin/stufe/04-verify-gates origin/stufe/05-verify-e2e -- $F
git diff origin/stufe/05-verify-e2e origin/stufe/06-verify-spec-abgleich -- $F
```

Ein Bericht mit „Issues found“ (aus `kurs/verify-rot`, dazu im Bonus mehr):

```bash
git show origin/kurs/verify-rot:specs/kategorien.verification.md | head -60
```

Weg A: `.claude/skills/verify/SKILL.md` in der Vorlage, Abschnitte 1-3 und 6.

</details>

## Rückfall

Weg B: `verify` v1 und `code` mit Fix-Liste aus der Musterlösung holen und committen, dann weiter mit Ü6:

```bash
M=origin/seminar/ue5-fix-list
git checkout $M -- .claude/skills/verify .claude/skills/code
git commit -m "feat(skills): verify v1 and fix list (Musterlösung Ü5)"
```

Ganz neu einsteigen: `git switch --no-track -c seminar/ab-ue6 origin/seminar/ue5-fix-list`.

Codex danach spiegeln bzw. Copilot in VS Code, falls nötig (nur den Kasten für euer Tool):

```bash
# Codex
mkdir -p .agents && cp -R .claude/skills .agents/
```

```bash
# Copilot in VS Code
mkdir -p .github && cp -R .claude/skills .github/
```

Weg A: Minimum für Ü6 ist ein `verify`-Skill, der eure schnellen Gates fährt und einen Bericht schreibt. Den Abgleich mit den Kriterien ergänzt ihr, wenn Zeit ist.

## Bonus für Schnelle

**Findet euer Verify den eingebauten Fehler, und behebt ihn `/code` über die Fix-Liste?** `kurs/verify-rot` enthält wieder den Leerzustand-Fehler aus Ü1 (Open-Tab bei aktivem Filter). Lasst eure eigenen Skills darauf los. Den Musterbericht löscht ihr vorher, sonst liest der Agent die Lösung ab.

Geht nur, wenn euer `verify` auf eurem Branch committet ist (Weg B, Schritt 2). Sonst testet ihr still den Muster-Skill aus `kurs/verify-rot`. Erst prüfen, nur bei `ok` weiter:

```bash
git cat-file -e HEAD:.claude/skills/verify/SKILL.md 2>/dev/null \
  && echo "ok" || echo "STOPP: erst euren verify-Skill committen"
```

```bash
B=$(git branch --show-current)
git switch --no-track -c seminar/verify-rot origin/kurs/verify-rot
git rm -rq .claude/skills/verify
git checkout "$B" -- .claude/skills/verify .claude/skills/code
git rm -q specs/kategorien.verification.md
git commit -m "chore: eigenen verify-Skill auf verify-rot testen"
```

Neue Session, `/verify specs/kategorien.md`. Erwartet: E2E rot (E4 in `e2e/specs/categories.spec.ts`), AC5 `not met`, Gesamturteil „Issues found“. Eure Fix-Liste nennt E2E und AC5. Vergleichen mit `git show origin/kurs/verify-rot:specs/kategorien.verification.md` (älter, noch ohne Fix-Liste). Dann neue Session, `/code specs/kategorien.md`: Erwartet sind Commits `fix: … (F1)` mit Haken in der Liste, danach `/verify` erneut mit Pass. Zurück: `git switch "$B"`.

Weitere Ideen: Weg B Issue #2 verifizieren. Weg A: ein Kriterium absichtlich brechen und prüfen, ob Verify es merkt (danach `git checkout -- .`).

## Für den Debrief

Leitfrage: **Wer hat etwas Rotes gefunden? Was hat Verify übersehen? Steht jeder Befund in der Fix-Liste?**

- Debrief-Beitrag (Debrief-Person, in den globalen Chat): euer Gesamturteil, der wichtigste Befund (oder „Pass, aber …“) und eine Frage.
- Im Plenum zeigen zwei Räume ihren Bericht. Der Kursleiter zeigt den Bericht von `kurs/verify-rot`.
