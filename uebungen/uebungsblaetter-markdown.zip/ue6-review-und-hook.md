# Ü6 Review-Subagent und Browser-Check

**Tag 2 · Donnerstag 19.11., nach dem Mittag · Zeitbox 70 Minuten**

## Ziel

Zwei Werkzeuge gegen „der Agent prüft sich selbst gnädig“: Ein Review-Subagent mit frischem Context Window, der nur liest. Und ein Browser-Check in `verify`, der jedes Akzeptanzkriterium im echten Browser klickt, wie ein User, mit Reload und Handy-Breite.

**Done, wenn …**

- [ ] ein Review-Subagent existiert (Claude Code: `.claude/agents/reviewer.md`): frischer Kontext, **nur lesend**, Findings mit Datei, Zeile und Schwere (blocking / non-blocking),
- [ ] `verify` ihn aufruft, ihm nur Spec-Pfad und Branch gibt (nicht die eigenen Schlüsse), jedes Finding selbst nachprüft und ein offenes blockierendes Finding das Gesamturteil auf „Issues found“ setzt,
- [ ] der Reviewer **einmal geprüft** hat (allein oder in `/verify`) und ihr seine Findings gelesen habt,
- [ ] `verify` den Schritt **„Browser walk“** hat: jedes Kriterium, das ein User sieht, im Browser, dazu Reload, Konsole und Handy-Breite,
- [ ] `/verify` **einmal mit Browser-Check gelaufen** ist und der Bericht den Abschnitt `## Browser walk` mit Schritten und Ergebnis enthält.

Das Gesamturteil muss nicht „Pass“ sein. Ein ehrliches „Issues found“ mit Browser-Schritten im Bericht ist auch Done.

## Zeitplan

| Min. | Was |
|---|---|
| 0-5 | Blatt lesen. `playwright-cli --version` prüfen, Port frei? (`lsof -i :3110`) |
| 5-22 | Reviewer schreiben, in `verify` einbauen |
| 22-32 | Reviewer allein ausprobieren (Prompt unten), Findings selbst prüfen |
| 32-44 | Schritt „Browser walk“ in `verify` einbauen, `playwright-cli` einmal von Hand testen |
| 44-62 | Neue Session, `/verify specs/<slug>.md` (Weg B ca. 15 Min.). Währenddessen im Raum vergleichen: Was hat der Reviewer gefunden? |
| 62-66 | Bericht prüfen: `## Review findings`, `## Browser walk`, Gesamturteil |
| 66-70 | Debrief-Person notiert den Debrief-Beitrag und postet ihn in den globalen Chat, aus dem Raum oder gleich nach der Rückkehr |

Tipp: Zur Halbzeit (nach ca. 35 Minuten) kurz aufstehen, strecken, Wasser holen. Laufende Agenten laufen weiter. Der Kursleiter kommt reihum in die Räume. Wer hängt: erst die gestuften Hilfen unten im Übungsheft, dann die Gruppe, dann dem Kursleiter im globalen Chat schreiben (Raum und ein Satz).

## Weg A: euer Repo

1. Reviewer aus der Vorlage übernehmen und lesen:

   ```bash
   mkdir -p .claude/agents
   cp ../rheinwerk-starter-skills/.claude/agents/reviewer.md \
     .claude/agents/reviewer.md
   ```

   Passt die Liste „Look for“ an euren Stack an (z. B. Migrations, API-Verträge, Berechtigungen).
2. In eurem `verify` den Abschnitt „Fresh review“ aus der Vorlage wieder einfügen (in Ü5 gelöscht), dazu den Berichtsabschnitt „Review findings“ und die Bedingung „no blocking finding is open“ beim Gesamturteil.
3. Den Abschnitt „Browser walk“ aus der Vorlage wieder einfügen, ebenso die Spalte `Browser` in der Kriterien-Tabelle, den Berichtsabschnitt `## Browser walk` und die Bedingung „every user-facing criterion passed in the browser“. Unter `## Settings` „Dev server and URL“ füllen: Startbefehl, Port, Test-Login. Als Browser-Werkzeug `playwright-cli` eintragen, die Befehle zeigt Hilfe 2.
4. `playwright-cli` einmal von Hand gegen euren Dev-Server testen (Weg B, Schritt 4, mit eurer URL).
5. **Kein UI in eurem Repo (reines Backend)?** Dann macht den Browser-Check in Weg B. In eurem Repo wird aus dem Schritt ein echter Aufruf gegen den laufenden Dienst (`curl` oder HTTP-Client), mit derselben Regel: Was nur im Code gelesen wurde, gilt nicht als geprüft.
6. Committen, neue Session, `/verify specs/<slug>.md`. Danach den Bericht lesen.

## Weg B: Demo-Fork

1. **Reviewer** als `.claude/agents/reviewer.md` schreiben (Gerüst in Hilfe 2). Kern: `tools: Read, Grep, Glob, Bash`, Bash nur für lesende Git-Befehle, Eingabe nur Spec-Pfad und Branch, Ausgabe als Tabelle mit `Severity | File:line | Finding`.
2. In `.claude/skills/verify/SKILL.md` nach „Gates“ einfügen:

   ```markdown
   ## Fresh review

   Start the **reviewer** subagent (`.claude/agents/reviewer.md`). It begins with an
   empty context, so the review is not anchored on your own view. Give it only the
   spec path and the branch, not your conclusions. Check each finding yourself in the
   code before you put it in the report, and drop the ones that do not hold.
   ```

   Im Bericht den Abschnitt `## Review findings` mit `### Blocking` und `### Non-blocking` ergänzen, beim Gesamturteil „no blocking review finding is open“. Committen:

   ```bash
   git add .claude && git commit -m "feat(skills): add a fresh reviewer to verify"
   ```

3. Reviewer allein ausprobieren (Prompt unter „Reviewer allein ausprobieren“). Jedes Finding im Code nachsehen: Hält es?
4. **`playwright-cli` von Hand testen**, im Fork-Ordner:

   ```bash
   echo ".playwright-cli" >> .gitignore
   PORT=3110 npm run dev
   ```

   In einem zweiten Terminal:

   ```bash
   playwright-cli open http://localhost:3110/login
   playwright-cli snapshot
   playwright-cli close
   ```

   `snapshot` zeigt die Elemente mit Referenzen wie `e12`. Danach den Dev-Server stoppen (Ctrl-C), sonst nutzt der E2E-Lauf ihn statt des Builds. Startet kein Browser: `playwright-cli install-browser`.
5. **Browser walk** in `verify` einfügen, nach „Fresh review“ (Gerüst in Hilfe 2). Dazu im Bericht die Spalte `Browser` in der Kriterien-Tabelle und den Abschnitt `## Browser walk`, beim Gesamturteil „every user-facing criterion passed in the browser“. Committen:

   ```bash
   git add .claude .gitignore
   git commit -m "feat(skills): walk the acceptance criteria in a browser"
   ```

6. Port frei (`lsof -i :3110` leer), neue Session:

   ```text
   /verify specs/kategorien.md
   ```

   Rechte: Die Allow-Liste aus Ü4 kennt `playwright-cli` noch nicht. Ergänzt in `.claude/settings.local.json` `"Bash(playwright-cli *)"`, `"Bash(PORT=3110 npm run dev)"` und `"Bash(curl -sf http://localhost:3110/*)"`, oder bestätigt die Befehle einzeln.
7. Bericht prüfen: Steht unter `## Browser walk` pro Kriterium, was geklickt und gesehen wurde, inklusive Reload? Was steht unter „Not verified“?

## Reviewer allein ausprobieren

Neue Session:

```text
Starte den Subagenten reviewer.
Gib ihm nur: Spec specs/kategorien.md, Branch <euer Branch>, Basis main.
Zeig mir seine Findings unverändert und prüfe danach jedes Finding selbst im Code.
```

## Pro Tool

| Tool | Reviewer | Browser-Check |
|---|---|---|
| Claude Code | `.claude/agents/reviewer.md`, `tools: Read, Grep, Glob, Bash`. `/agents` zeigt ihn. | `playwright-cli` über Bash. Im Auto-Modus prüft der Klassifizierer die Befehle, sonst Allow-Liste (Weg B, Schritt 6). |
| Codex | `.codex/agents/reviewer.toml` aus der Vorlage (`name`, `description`, `developer_instructions`). Codex erzwingt „nur lesen“ nicht pro Agent, der Subagent erbt die Sandbox der Session. Der Skill muss ihn ausdrücklich starten („Spawn the reviewer subagent …“). | Startet der Browser oder der Dev-Server in der Sandbox nicht, im Demo-Fork Full Access über `/permissions`. Skill danach neu spiegeln. |
| Cursor | `.cursor/agents/reviewer.md` oder er liest `.claude/agents/`. Frontmatter `readonly: true` macht ihn schreibgeschützt. | `playwright-cli` im Terminal, Auto-Run nur mit Allowlist. |
| Copilot | `.github/agents/reviewer.agent.md`, Tools auf Lesen beschränken, z. B. `tools: ['read', 'search']`. „Do not edit“ im Text allein ist keine Grenze. | `playwright-cli` im Terminal, Befehle freigeben (VS Code) bzw. bestätigen (CLI). |

Für alle gilt: `playwright-cli` ist ein normales Kommandozeilen-Werkzeug. Was ihr von Hand im Terminal startet, kann jeder Agent starten, wenn er Terminal-Befehle ausführen darf.

## Gestufte Hilfen

<details>
<summary>Hilfe 1: Denkanstoß</summary>

- Der Reviewer bekommt bewusst **nicht** die Begründung des Autors. Er urteilt über den Code, nicht über die Erklärung.
- Ein Finding, das der Hauptagent im Code nicht findet, fliegt raus. Sonst landen Vermutungen im Bericht.
- Gates und Tests prüfen, was jemand vorher als Test geschrieben hat. Der Browser-Check prüft, was ein User sieht: leerer Zustand, Reload, Handy-Breite, Fehler in der Konsole.
- Harte Regel im Skill: Ein Kriterium gilt nur dann als im Browser geprüft, wenn der Agent es wirklich geklickt hat. Fehlt der Browser, steht das unter „Not verified“.

</details>

<details>
<summary>Hilfe 2: Gerüste zum Kopieren</summary>

`.claude/agents/reviewer.md`:

````markdown
---
name: reviewer
description: Read-only reviewer of a branch against its spec. Never edits files.
tools: Read, Grep, Glob, Bash
---

You review one feature branch. You start without the author's context on purpose.
You only read. Use Bash only for read-only git commands (`git diff`, `git log`,
`git show`). Never edit files, never change the index or branches, run no tests.

Input: the spec path and the branch. Nothing else.

1. Read the spec, `AGENTS.md` and the ADRs the diff touches.
2. Read `git diff main...HEAD`, open changed files where the diff is not enough.
3. Look for: wrong behavior against the spec, missed edge cases (empty states,
   active filters, reload, old data, mobile), violated ADRs or hard rules,
   criteria no test would catch, scope creep.
4. Check each finding in the code. Drop what you cannot point to.

Output, at most about 40 lines:
| # | Severity | File:line | Finding | Why it matters |
Severity: blocking or non-blocking. Then "Checked and fine", one line per area.
````

Abschnitt „Browser walk“ für `.claude/skills/verify/SKILL.md` (Weg B, wie Stufe 8):

````markdown
## Browser walk

Walk each user-facing acceptance criterion in a real browser, like a user would.

1. Start the app in the background: `PORT=3110 npm run dev`, and wait until
   `curl -sf http://localhost:3110/login` answers. Never use port 3000.
2. Drive it with `playwright-cli`: `playwright-cli open <url>`, then `snapshot`
   for element refs, `click <ref>`, `fill <ref> <text>`, `goto <url>`, `reload`,
   `resize <w> <h>` and `console error`.
3. Log in with the demo login. Load demo data or create the habits you need.
4. For every criterion: do the steps, check the result in the snapshot, then
   `reload` and check again. Check the console for errors.
5. Look at the affected screens at 1280x800 and at 390x844 (mobile bottom nav).
6. Note every step and what you saw. The report lists them.
7. `playwright-cli close` and stop the dev server. A dev server left running on
   3110 would be reused by the next `test:e2e` run instead of the build.

If `playwright-cli` is missing or no browser starts, say so in the report. Never
mark a criterion as verified in the browser when you only read the code.
````

Im Bericht:

```markdown
## Acceptance criteria
| AC | Code + test | Browser | Result |

## Browser walk
Numbered steps per criterion: what you clicked and what you saw, incl. the reload.
```

</details>

<details>
<summary>Hilfe 3: Musterlösung ansehen</summary>

```bash
F=.claude/skills/verify/SKILL.md
git show origin/stufe/07-verify-review:.claude/agents/reviewer.md
git diff origin/stufe/06-verify-spec-abgleich origin/stufe/07-verify-review -- $F
git diff origin/stufe/07-verify-review origin/stufe/08-verify-browser -- $F
git show origin/stufe/08-verify-browser:specs/kategorien.verification.md
```

Der letzte Befehl zeigt einen echten Bericht mit Browser-Schritten.

Weg A: `.claude/agents/reviewer.md` und die Abschnitte „Fresh review“ und „Browser walk“ in `.claude/skills/verify/SKILL.md` der Vorlage, für Codex `.codex/agents/reviewer.toml`.

</details>

## Rückfall

Weg B: Reviewer und `verify` mit Review und Browser-Check aus Stufe 8 holen, dann weiter mit Ü7:

```bash
git checkout origin/stufe/08-verify-browser -- .claude/agents \
  .claude/skills/verify .gitignore
git commit -m "feat(verify): reviewer and browser walk (Musterlösung Stufe 8)"
```

Das überschreibt euren `verify` mit der Musterlösung. Codex danach spiegeln. Den einen `/verify`-Lauf mit Browser-Check holt ihr trotzdem nach, er ist Teil von Done.

Startet bei euch kein Browser, auch nicht nach `playwright-cli install-browser`? Dann lasst `/verify` trotzdem laufen. Der Bericht muss unter „Not verified“ sagen, dass der Browser fehlte. Sagt es dem Kursleiter im globalen Chat.

Weg A: Minimum für Ü7 ist der Reviewer aus der Vorlage in eurem `verify`. Den Browser-Check holt ihr in Weg B nach.

## Bonus für Schnelle

- Reviewer auf `kurs/verify-rot` loslassen (Branch aus dem Ü5-Bonus). Findet er den Leerzustand-Fehler als „blocking“? Und findet ihn der Browser-Check?
- Browser-Check gegen einen absichtlichen Fehler: in einer Komponente den Filter kaputt machen, `/verify` laufen lassen, danach `git checkout -- app`. Merkt es der Browser-Check, bevor ein Test es merkt?
- In `verify` einen Screenshot pro Kriterium ablegen lassen (`playwright-cli screenshot`) und im Bericht verlinken.

### Bonus BMad: zweites Review mit `bmad-code-review`

Nur, wenn Reviewer und Browser-Check stehen. Ihr lasst das Review von [BMad Method](https://github.com/bmad-code-org/BMAD-METHOD/blob/V6.12/docs/build/review-a-change.md) 6.12.4 mit **einer eigenen Review-Ebene** neben eurem `reviewer` auf denselben Diff los und vergleicht. `bmad-code-review` bringt vier Ebenen mit: Blind Hunter (sieht nur den Diff), Edge Case Hunter, Verification Gap und Acceptance Auditor (Diff gegen Spec, nur mit Spec-Pfad). Jeder Befund bekommt eine Triage: `decision_needed`, `patch`, `defer` oder `dismiss`.

Was gleich bleibt: **Euer Browser-Check und, ab Ü7, eure Hooks.** BMad klickt nicht durch die App und hat keine Hooks. Eine Review-Ebene ist eine Bitte an ein Modell, ein Hook läuft immer.

Im Test (Demo-Repo, Claude Code, Sonnet): erster Lauf 3 Patches, 1 Defer, 13 verworfen; im zweiten Lauf lief die eigene Ebene mit. Voraussetzungen wie im Ü3-Bonus (Vorab-Info).

1. **Wegwerf-Worktree.** Weg B, und Weg A zum Ausprobieren: aus `origin/bmad/05-verify-hooks`. Dort sind BMad, das fertige Feature zu Issue #1 und die BMad-Spec mit `baseline_commit`. Im Fork-Ordner (fehlen die `bmad/*`-Branches: Block im Ü3-Bonus):

   ```bash
   git fetch origin
   git worktree add -b wegwerf/bmad-review ../habit-review \
     origin/bmad/05-verify-hooks
   cd ../habit-review
   printf '%s\n' '[core]' 'user_name = "Vorname Nachname"' \
     'communication_language = "German"' > _bmad/custom/config.user.toml
   ```

   Im eigenen Repo (Weg A) geht es auch: Installation wie im Ü3-Bonus, Variante 2, aber den Worktree aus eurem Übungs-Branch statt aus `origin/main`. Merkt euch dort vor der Installation die Commits eures Features, ihr braucht sie in Schritt 3:

   ```bash
   echo "$(git merge-base origin/main HEAD)..$(git rev-parse HEAD)"
   ```

2. **Eigene Ebene** in `_bmad/custom/bmad-code-review.toml`: eine Team-Regel, die die vier Ebenen nicht prüfen. Weg B, die Datei aus dem Testlauf (dort geladen und gelaufen):

   ```bash
   mkdir -p _bmad/custom
   cat > _bmad/custom/bmad-code-review.toml <<'TOML'
   # Team review layer for bmad-code-review (committed).
   [[workflow.review_layers]]
   id = "schema-test-guard"
   name = "Schema Test Guard"
   instruction = """
   Launch a context-free subagent with this prompt:

   You check one team rule. Read the unified diff at `{diff_file}`.
   Rule: every change to `app/types/app-data.ts` or `app/utils/persistence/`
   needs a matching new or changed test in `tests/` in the same diff, and a
   new ADR in `docs/adr/`.
   For each changed schema file, name the test file that covers it, or report
   "missing test for <file>". Report "missing ADR" if no ADR file is added.
   Output a Markdown list of findings only; say "no findings" if the rule holds.

   Do not invoke any skill, and do not spawn subagents of your own. Return your
   findings as text in your final message.
   """
   TOML
   ```

   Weg A: `id`, `name` und die Zeilen unter `Rule:` tauschen, z. B. „jede neue API-Route hat einen Eintrag in `api/openapi.yaml`“. Eine Regel, am Diff prüfbar. Neue `id` hängt eine Ebene an, eine bestehende `id` ersetzt die Standard-Ebene. Prüfen ohne Agent, dann committen:

   ```bash
   uv run --no-cache _bmad/scripts/resolve_customization.py \
     --skill "$PWD/.claude/skills/bmad-code-review" -p "$PWD" \
     --key workflow.review_layers | grep '"id"'
   git add _bmad/custom/bmad-code-review.toml
   git commit -q -m "chore(bmad): add review layer"
   ```

   Erwartet: die vier Standard-IDs und eure als fünfte. Codex, Cursor, Copilot: `.agents/skills/bmad-code-review` im Befehl.
3. **Frische Session, Review mit Spec-Pfad.** Ohne Spec-Pfad vergleicht der Skill den Branch gegen `main`, und dann liegt die ganze BMad-Installation im Diff. Weg B:

   ```text
   /bmad-code-review _bmad-output/implementation-artifacts/spec-<slug>.md
   ```

   Den Slug zeigt `ls _bmad-output/implementation-artifacts/`, auf `bmad/05-verify-hooks` ist es `gh-1-habit-categories-filter`.

   Im eigenen Repo gibt es keine BMad-Spec. Dann mit den Commits aus Schritt 1, ohne Spec (so getestet, der Acceptance Auditor läuft dann nicht):

   ```text
   /bmad-code-review commit range <von>..<bis>, no spec
   ```

4. **Das Review hält bis zu dreimal an.**
   - **Halt 1, Kontext:** Ziel, Modus und Umfang. Weg B: ca. 40 Dateien ab `baseline_commit`. Stimmt das, „weiter“. Nennt es Hunderte Dateien: abbrechen, Spec-Pfad oder Range prüfen. Eure Ebene muss unter den aktiven Ebenen stehen.
   - **Halt 2, Entscheidungen:** nur, wenn es Befunde mit `decision_needed` gibt. Mit der Nummer der Option antworten.
   - **Halt 3, Patches:** `1` alle anwenden, `2` als Action Items stehen lassen, `3` einzeln durchgehen. Für den Vergleich: **`2`**.

   Der Skill schreibt die Befunde als Abschnitt in die Spec, Defers nach `deferred-work.md`. **Patches committet er nicht selbst.** Wer im Wegwerf-Worktree `1` wählt, prüft jeden Patch selbst und committet ihn selbst. Empfiehlt er am Ende `dev-story`: ignorieren, das ist in 6.12 veraltet.
5. **Euren `reviewer` auf denselben Diff.** Kopiert ihn aus eurem Übungs-Branch in den Worktree und startet eine neue Session (Weg B, Fork-Ordner heißt hier `../habit-tracker-demo`):

   ```bash
   mkdir -p .claude/agents
   cp ../habit-tracker-demo/.claude/agents/reviewer.md .claude/agents/
   ```

   ```text
   Starte den Subagenten reviewer.
   Gib ihm nur: Spec _bmad-output/implementation-artifacts/spec-<slug>.md,
   Branch HEAD, Basis 365e464.
   Zeig mir seine Befunde unverändert.
   ```

   `365e464` ist der `baseline_commit` der Spec, also derselbe Diff wie bei BMad. Weg A: eure Range aus Schritt 1.
6. **Vergleichen.** Was fanden beide? Was nur BMad, was nur euer Reviewer? Welcher Befund war falsch? Was hat eure eigene Ebene gemeldet, und gehört die Regel besser in einen Hook (Ü7)?
7. **Aufräumen**, im Haupt-Checkout:

   ```bash
   git worktree remove --force ../habit-review
   git branch -D wegwerf/bmad-review
   ```

<details>
<summary>Fallstricke BMad-Review (aus den Testläufen)</summary>

- **Spec-Pfad oder Range angeben.** Ohne beides fragt das Review, ob es gegen `main` prüfen soll. Im Wegwerf-Branch läge dann die BMad-Installation im Diff.
- **Review findet immer etwas.** Der Blind Hunter muss je nach Diff-Größe eine Mindestzahl an Befunden liefern. Im Test fand ein Review der Review-Patches wieder zwei neue. Höchstens zwei Läufe, der Rest wird ein Ticket.
- **Nichts wird committet.** Patches liegen danach ungestaged im Worktree. Im Test hat der Agent beim Patchen ein akzeptiertes ADR geändert, obwohl `AGENTS.md` das verbietet: jeden Patch selbst lesen.
- **Sprache:** Ohne `_bmad/custom/config.user.toml` antwortet das Review auf Englisch.
- **Ohne Subagenten** schreibt das Review laut Quelltext die Prompts der Ebenen in Dateien unter `_bmad-output/implementation-artifacts/` und hält an, sonst laufen die Ebenen nacheinander in der Hauptsession, laut BMad deutlich schwächer.
- **Codex, Cursor, Copilot:** Skills unter `.agents/skills/` (auf `bmad/05-verify-hooks` nur unter `.claude/skills/`, für Codex spiegeln wie im Ü3-Bonus). Copilot in VS Code liest laut Doku `.github/skills/`: `/` tippen, sonst spiegeln. **Agentenläufe in Codex, Cursor und Copilot sind nicht getestet.**
- **`npx skills add …` nicht ausführen,** auch wenn der Installer es empfiehlt (holt v7).
- **Override wirkt erst in einer neuen Session.** Eine laufende Session nutzt den Stand vom Start.

</details>

## Für den Debrief

Leitfrage: **Was hat der Reviewer gefunden, und was hat erst der Browser gezeigt?**

- Debrief-Beitrag (Debrief-Person, in den globalen Chat): das beste Finding des Reviewers, ein Browser-Schritt, der etwas gezeigt hat, das Gesamturteil, eine Frage.
- Im Plenum zeigen zwei Räume ihren Bericht mit `## Browser walk`. Der Kursleiter zeigt danach den Bericht aus Stufe 8.
