# Ü1 Freier Prompt, ehrlich geprüft

**Tag 1 · Mittwoch 18.11., vor dem Mittag · Zeitbox 60 Minuten**

## Ziel

Ihr gebt dem Agenten eine Aufgabe so, wie die meisten heute prompten, und prüft das Ergebnis ehrlich. Heraus kommt die Liste, mit der ihr ab Ü2 eure `AGENTS.md` und euren Spec-Skill füttert.

**Done, wenn …**

- [ ] ein freier Lauf in einem Wegwerf-Worktree durchgelaufen ist (oder ihr den Rückfall-Stand prüft),
- [ ] ihr das Ergebnis mit der Prüf-Checkliste angesehen habt, inkl. Neuladen im Browser bzw. in der App,
- [ ] eure Liste **„Was der Agent nicht wusste“** mindestens 5 Punkte hat, **jeder mit Datei oder Regel**, wo es steht oder stehen müsste.

## Zeitplan

| Min. | Was |
|---|---|
| 0-10 | Blatt lesen, Wegwerf-Worktree anlegen, Abhängigkeiten installieren |
| 10-25 | Freien Prompt starten. Rückfragen nur mit „mach einfach“. Währenddessen: Was erwartet ihr? Notiert drei Tipps, was schiefgeht. |
| 25-40 | Ergebnis prüfen: erst die Prüf-Checkliste, dann (Weg B) die versteckte Komplexität in Hilfe 3 aufklappen |
| 40-50 | Liste „Was der Agent nicht wusste“ schreiben, im Raum vergleichen und zusammenführen |
| 50-55 | Debrief-Person notiert den Debrief-Beitrag (ein Ergebnis, eine Frage) und postet ihn in den globalen Chat, aus dem Raum oder gleich nach der Rückkehr |
| 55-60 | Puffer. Der Worktree bleibt bis nach dem Debrief stehen. |

Der Kursleiter kommt reihum in die Räume. Wer hängt: erst die gestuften Hilfen unten, dann die Gruppe, dann dem Kursleiter im globalen Chat schreiben (Raum und ein Satz).

## Die Liste „Was der Agent nicht wusste“

Kopiert die Tabelle in eine Notiz. Sie ist der Input für Ü2.

| # | Was der Agent nicht wusste oder falsch gemacht hat | Wo es steht bzw. stehen müsste (Datei, Regel, ADR) | Gehört in … (`AGENTS.md`, ADR, Spec, Hook, Ticket) |
|---|---|---|---|
| 1 | | | |
| 2 | | | |
| 3 | | | |
| 4 | | | |
| 5 | | | |

Faustregel für die letzte Spalte: gilt für jede Aufgabe → `AGENTS.md`. Ist eine Entscheidung mit Begründung → ADR. Gilt nur für dieses Feature → Spec bzw. Ticket. Bricht immer wieder, egal was im Prompt steht → Hook (Tag 2).

## Weg A: euer Repo

1. Wegwerf-Worktree aus eurem Basis-Branch anlegen (Name und Basis anpassen):

   ```bash
   git fetch origin
   git worktree add ../mein-repo-frei origin/main
   cd ../mein-repo-frei
   ```

   Dann die Abhängigkeiten installieren wie bei euch üblich (`npm ci`, `./gradlew build -x test`, `mvn -q install -DskipTests`, …).

   Zu groß oder zu langsam? Nehmt stattdessen einen Wegwerf-Branch im Haupt-Checkout. Vorher muss der Arbeitsstand leer sein (eigene Änderungen erst committen), denn beim Aufräumen in Schritt 6 wird alles Ungespeicherte verworfen:

   ```bash
   git status --short  # muss leer sein
   git switch -c frei/test
   ```

2. Agent **im Worktree** starten, neue Session, und euer Ticket so knapp eingeben, wie es im Tracker steht. Nur Titel bzw. ein Satz, keine Hinweise auf Architektur oder Regeln. Beispiel:

   ```text
   <Ticket-Titel>: <ein Satz aus der Beschreibung>
   ```

3. Alle Rückfragen nur mit `mach einfach` beantworten. Rechte-Abfragen erlauben, solange sie im Worktree bleiben.

   **Claude Code ab 2.1.283** startet im Auto-Modus (Statuszeile `auto mode on`). Dann gibt ein Klassifizierer-Modell Routine-Aktionen frei, und ihr seht kaum Abfragen. Verlangt eure Firma Einzelfreigaben, startet mit `claude --permission-mode default` oder drückt in der Session einmal Shift+Tab (von `auto` springt es auf `default`). Hat eure Firma den Auto-Modus per Managed Settings gesperrt, fehlt er im Shift+Tab-Zyklus.
4. Prüf-Checkliste (unten) durchgehen. Dann eure eigene versteckte Komplexität suchen: Welche Stellen müssten bei diesem Ticket mitgeändert werden, die man im Ticket nicht sieht? Hilfe 3 zeigt, wie das im Demo-Repo aussieht.
5. **Vertraulichkeit:** Im Raum teilt ihr die Liste, nicht den Code. Firmen-Dateinamen dürft ihr allgemein halten („unser Mapper im API-Layer“).
6. Nach dem Debrief aufräumen. Vom freien Lauf darf nichts in euren echten Branch gelangen, auch keine neuen Dateien. Nur den Kasten für euren Fall:

   ```bash
   # Worktree: zurück in den Haupt-Checkout (Ordnername anpassen)
   cd ../<euer-repo>
   git worktree remove --force ../mein-repo-frei
   ```

   ```bash
   # Wegwerf-Branch: alles des Agenten verwerfen, dann zurück
   git reset -q --hard && git clean -fdq
   git switch - && git branch -D frei/test
   git status --short  # leer
   ```

   Zeigt `git status --short` danach noch etwas, nichts committen und den Kursleiter holen.

**Kein passendes Ticket oder der Agent darf nicht ran?** Macht Ü1 in Weg B. Die Liste aus dem Demo-Repo zeigt dieselben Muster.

## Weg B: Demo-Fork

1. Wegwerf-Worktree aus `origin/main` (im Fork-Ordner `habit-tracker-demo`):

   ```bash
   git fetch origin
   git worktree add ../habit-frei origin/main
   cd ../habit-frei
   npm ci
   ```

   Der Worktree hat einen „detached HEAD“. Das ist für einen Wegwerf-Lauf richtig so.
2. Agent **in `../habit-frei`** starten, neue Session. Prompt wörtlich:

   ```text
   Füge Kategorien für Habits hinzu, mit Filter
   ```

3. Jede Rückfrage nur mit `mach einfach` beantworten. Rechte erlauben. Läuft ca. 4-10 Minuten.
4. Prüf-Checkliste (unten), dann Hilfe 3 aufklappen und die versteckte Komplexität nachprüfen.
5. Nach dem Debrief aufräumen (vom Fork-Ordner aus):

   ```bash
   cd ../habit-tracker-demo
   git worktree remove --force ../habit-frei
   ```

## Prüf-Checkliste (für beide Wege, erst nach dem Lauf)

- [ ] **Läuft es?** App starten, Feature einmal benutzen. Weg B: `PORT=3110 npm run dev`, auf `/login` „Continue with demo login“, unter „Settings“ „Load demo data“, Kategorie zuweisen, filtern. Wege: README, Abschnitt „Die Demo-App in 2 Minuten“.
- [ ] **Überlebt es Neuladen?** Seite neu laden. Ist die Zuordnung noch da? Steht der Filter in der URL?
- [ ] **Gates grün?** Weg B: `npm run lint && npm run typecheck && npm test`.
- [ ] **Was hat sich geändert?** `git add -A && git diff --stat origin/main`. Wo hat der Agent nichts angefasst, obwohl er hätte müssen?
- [ ] **Tests?** Gibt es neue Tests? Prüfen sie das Verhalten aus dem Ticket oder nur, dass der Code existiert?
- [ ] **Annahmen?** Was hat der Agent entschieden, ohne zu fragen (feste Liste oder Freitext, Pflichtfeld oder leer)?
- [ ] **Leere und Sonderfälle?** Was zeigt die Ansicht, wenn der Filter nichts findet?

## Pro Tool

| Tool | Neue Session im Worktree | Hinweis |
|---|---|---|
| Claude Code | `cd ../habit-frei && claude` | Läuft ohne `CLAUDE.md`/`AGENTS.md`, genau das wollen wir hier. Ab 2.1.283 im Auto-Modus: kaum Rechte-Prompts, im Wegwerf-Worktree passt das. Ältere Version oder Standard-Modus: großzügig erlauben. |
| Codex | `cd ../habit-frei && codex` | Fragt nach Vertrauen für den Ordner: ja. Rechte mit `/permissions`. |
| Cursor | Ordner `habit-frei` als eigenes Fenster öffnen (File → Open Folder), Agent-Chat | Nicht im Fenster des Haupt-Checkouts arbeiten, sonst ändert der Agent den falschen Ordner. |
| Copilot | VS Code: `code ../habit-frei`, Chat im Agent-Modus. CLI: `cd ../habit-frei && copilot` | Wie Cursor: eigenes Fenster pro Worktree. |

## Gestufte Hilfen

<details>
<summary>Hilfe 1: Denkanstoß</summary>

Schaut nicht nur auf die Dateien, die der Agent geändert hat, sondern auf die, die er **nicht** angefasst hat. Wo wird das Datenmodell noch gelesen, geschrieben, validiert, exportiert, importiert, angezeigt? Wo stehen im Repo Regeln, die eine solche Änderung betreffen (`docs/`, ADRs, README)?

</details>

<details>
<summary>Hilfe 2: Prompt, um die Liste mit dem Agenten zu prüfen</summary>

Neue Session (nicht die des freien Laufs, die ist voreingenommen):

```text
Ein Agent hat in diesem Worktree das Feature "<Ticket-Titel>" gebaut, ohne Spec.
Vergleiche den Stand mit origin/main.
Liste die Stellen im Repo, die bei so einer Änderung mitgeändert werden müssten,
aber nicht geändert wurden.
Liste auch die Regeln in docs/ oder ADRs, gegen die die Änderung verstößt.
Je Punkt: Datei:Zeile und ein Satz warum. Ändere nichts.
```

Jeden Punkt selbst im Code nachprüfen, bevor er auf die Liste kommt.

</details>

<details>
<summary>Hilfe 3: Versteckte Komplexität im Demo-Repo (erst nach dem Lauf öffnen)</summary>

Quelle: die Referenz-Spec, Abschnitt „Research“:

```bash
git show origin/stufe/02-spec-voll:specs/kategorien.md \
  | sed -n '/## Research/,/## Requirements/p'
```

Die Prüfbefehle, im Worktree `../habit-frei` nach `git add -A` (Nummer = Zeile in der Tabelle darunter, einzeln oder alle auf einmal):

```bash
cd ../habit-frei && git add -A
# 1 Neues ADR?
git diff --stat origin/main -- docs
# 2 Zod-Schema
git diff origin/main -- app/utils/persistence/storage-schema.ts
# 3 Schema-Version
git grep -n "APP_DATA_SCHEMA_VERSION =" -- app/types/app-data.ts
# 4 Tab-Abgleich
git grep -n category -- app/utils/persistence/merge-app-data.ts
# 5 KI-Prompts
git grep -n category -- app/utils/domain/ai-prompts.ts
# 6 Demo-Daten
git grep -n category -- app/utils/domain/demo-data-generator.ts
# 7 Leerzustand
git grep -n "Everything due today" -- app
```

| # | Prüfpunkt | Was die Regel sagt |
|---|---|---|
| 1 | Neues ADR? | ADR-0006 und ADR-0022: Eine Änderung an der Datenform ist nie still, sie braucht eine Entscheidung (neues ADR) und eine Migration bzw. einen Default. |
| 2 | Zod-Schema | Die Zod-Schemas (`z.object`) verwerfen unbekannte Felder. Fehlt `category` im Schema, ist die Kategorie nach dem Neuladen weg. Auch das `LenientHabitImportSchema` für den Import prüfen. |
| 3 | Schema-Version und alte Daten | Steht auf 2. Bleibt sie, braucht das neue Feld einen Default für alte Daten und alte Backups (`migrateToV2`, `app/utils/persistence/backup.ts`). |
| 4 | Tab-Abgleich | `habitsEqualIgnoringId` vergleicht Feld für Feld. Fehlt das Feld, gehen Änderungen beim Abgleich zwischen Tabs verloren. |
| 5 | KI-Prompts | Beide Prompts listen jedes Habit-Feld. Kein Treffer heißt: vergessen. |
| 6 | Demo-Daten | Ohne Kategorien in den Demo-Daten zeigt der Filter nichts. |
| 7 | Leerzustand | Today, Open-Tab, mit aktivem Filter: Sind alle Habits der Kategorie erledigt, behauptet die Ansicht „Everything due today has already been reviewed.“, obwohl Habits anderer Kategorien offen sind. Das Issue verbietet genau das. |

Leerzustand im Browser nachstellen: `PORT=3110 npm run dev`, „Continue with demo login“, zwei heute fällige Habits in Kategorie A, eins in B. Auf Today nach A filtern, beide erledigen, Tab „Open“ ansehen.

Weitere Kandidaten für die Liste: Port 3000 ist bei vielen belegt (Playwright nimmt ihn als Default), Node 22 Pflicht, Filter in der URL (`?category=`), Tests in `tests/` und `e2e/`, die ca. 20 Test-Literale für `Habit`.

</details>

## Rückfall

Weg B: Der Lauf hängt oder ist nicht fertig geworden? Nehmt das Ergebnis eines echten freien Laufs aus der Vorbereitung und prüft das (im Worktree):

```bash
cd ../habit-frei
git reset -q --hard origin/kurs/kategorien-prompt && git clean -fdq
git log --oneline -1
```

Dann Prüf-Checkliste und Hilfe 3 wie oben. Ihr seht dort u. a.: kein ADR unter `docs/`, kein Treffer in `ai-prompts.ts`, der falsche Leerzustand auf dem Open-Tab.

Weg A: Kein Lauf möglich? Schreibt die Liste aus dem Code: Welche fünf Dinge müsste ein neuer Kollege über euer Repo wissen, um das Ticket richtig zu bauen, und wo stehen sie (oder eben nicht)?

## Bonus für Schnelle

- Denselben Prompt noch einmal in einer neuen Session laufen lassen, vorher im Worktree zurücksetzen. Trifft der Agent dieselben Entscheidungen?

  ```bash
  git reset --hard origin/main && git clean -fd
  ```

- Weg A: zusätzlich Weg B laufen lassen und vergleichen, welche Muster gleich sind.
- Schätzt: Wie lange hätte das Review dieses Ergebnisses im Team gedauert, und wie viele Runden?

## Für den Debrief

Leitfrage: **Was wusste der Agent nicht, und wo hätte es gestanden?**

- Debrief-Beitrag (Debrief-Person, in den globalen Chat): die zwei überraschendsten Punkte eurer Liste (mit Datei oder Regel) und eine Frage.
- Im Plenum zeigen zwei Räume 3 Minuten ihre Liste, einer aus Weg A, einer aus Weg B.
- Hebt eure Liste auf. In Ü2 wird sie zu eurer `AGENTS.md`.
