# Ü0 Ankommen und Schnelltest

**Tag 1 · Mittwoch 18.11., zum Start · Zeitbox 30 Minuten**

## Ziel

Ihr habt eine laufende Umgebung und wisst, womit ihr die zwei Tage arbeitet.

**Done, wenn …**

- [ ] euer Schnelltest grün ist (Weg B: Fork, `npm ci`, Lint, Tests, App auf 3110; Weg A zusätzlich: Agent antwortet im Firmen-Repo),
- [ ] euer Tool im Skill-Test `/spec` anbietet (Claude Code: Version 2.1.277 oder neuer).

## Zeitplan

| Min. | Was |
|---|---|
| 0-5 | Kurze Runde: Name, Weg, Tool, Ticket in einem Satz. Rollen für Ü1 verteilen. |
| 5-20 | Schnelltest, Vorlage klonen, Skill-Test (`/` tippen, nicht ausführen), jede/r für sich. Wer fertig ist, hilft der Person, die hängt. |
| 20-25 | Lese-Frage an den Agenten, Antworten kurz vergleichen. |
| 25-30 | Debrief-Person postet den Raum-Stand in den globalen Chat, aus dem Raum oder gleich nach der Rückkehr, z. B. `R2: 4/4 grün, Weg B, 2x Claude Code, 1x Cursor, 1x Copilot`. |

## Weg A: euer Repo

1. Klärt für euch: Dürft ihr einen KI-Agenten auf diesem Code einsetzen? Im Zweifel geht ihr heute Weg B und übertragt später.
2. Build und Tests laufen lokal. Schreibt euch die Befehle auf, ihr braucht sie ab Ü2 als **Gates** (Lint, Typecheck bzw. Compile, Unit-Tests, ggf. E2E).
3. Ein Ticket ist ausgewählt: echt, klein (1-2 Tage), fachlich klar, nicht im sicherheitskritischsten Teil.
4. Ticket-CLI testen, je nach System:

   ```bash
   gh auth status && gh issue view <n>
   ```

   ```bash
   glab auth status && glab issue view <n>
   ```

   ```bash
   acli jira workitem view <KEY-123>
   ```

   **Geht die CLI im Firmennetz nicht** (Proxy, SSO, fehlende Rechte)? Kein Problem. Legt das Ticket als Datei an, ab Ü3 liest der Skill dann diese Datei:

   ```bash
   mkdir -p tickets && echo "tickets/" >> .git/info/exclude
   ```

   In `tickets/<KEY>.md` kopiert ihr Titel, Beschreibung und Akzeptanzkriterien aus dem Tracker. `.git/info/exclude` sorgt dafür, dass Firmen-Interna nicht versehentlich committet werden.
5. Agenten im Firmen-Repo starten und die Lese-Frage stellen (unten).
6. Zusätzlich den Fork aus Weg B anlegen. Er ist euer Rückfall und enthält die Musterlösungen.

## Weg B: Demo-Fork

```bash
gh repo fork dinooo13/habit-tracker-demo --clone
cd habit-tracker-demo
```

Habt ihr den Fork schon gestern angelegt: `cd habit-tracker-demo && git fetch origin`.

```bash
node -v  # v22.x
gh auth status
npm ci
npm run lint && npm test  # grün, ca. 30 Sekunden
npx playwright install chromium  # Browser für die E2E-Tests an Tag 2
git branch -r | grep -c 'origin/stufe/'  # 10
```

Zeigt der Branch-Check `0`, wurde der Fork im Browser mit dem Haken „Copy the main branch only“ angelegt. Dann die Branches einmal in euren Fork schieben, danach gelten alle Befehle mit `origin/` unverändert:

```bash
git remote add upstream \
  https://github.com/dinooo13/habit-tracker-demo.git 2>/dev/null
git fetch upstream
git push origin 'refs/remotes/upstream/stufe/*:refs/heads/stufe/*' \
  'refs/remotes/upstream/kurs/*:refs/heads/kurs/*'
git fetch origin
git branch -r | grep -c 'origin/stufe/'   # muss 10 zeigen
```

```bash
PORT=3110 npm run dev  # localhost:3110/login öffnen, App durchklicken, dann Ctrl-C
```

App einmal durchklicken (README, Abschnitt „Die Demo-App in 2 Minuten“). Kern: „Continue with demo login“, dann unter „Settings“ „Load demo data“, auf „Today“ bei einem Habit „Done“ klicken.

Die Vorlage für später einmal neben den Fork klonen (Weg A: klont sie neben euer Firmen-Repo, die Befehle ab Ü2 erwarten sie unter `../rheinwerk-starter-skills`):

```bash
git clone https://github.com/dinooo13/rheinwerk-starter-skills.git \
  ../rheinwerk-starter-skills
```

### Skill-Test: sieht euer Tool die Skills? (Weg A und B)

Ab Ü2 ruft ihr eigene Skills mit `/spec` auf. Prüft jetzt, ob euer Tool Skills aus `.claude/skills/` findet. Im Fork, in einem Wegwerf-Worktree mit dem Muster-Skill aus Stufe 1:

```bash
git worktree add ../habit-skilltest origin/stufe/01-spec-starter
ls ../habit-skilltest/.claude/skills  # spec
```

Tool **in `../habit-skilltest`** starten, `/` tippen. Steht `spec` in der Liste, ist alles gut. Nicht ausführen, nur schauen.

| Tool | `spec` fehlt? |
|---|---|
| Claude Code | `claude --version` muss mindestens 2.1.277 zeigen (siehe Pro Tool). Persönliche Skills gleichen Namens verschieben (Block unter Pro Tool). |
| Codex | Spiegeln nach `.agents/skills/` (Kasten unten), dann Codex neu starten. Aufruf `$spec` bzw. `/skills`. |
| Cursor | Neuer Chat. Hilft das nicht, spiegeln nach `.cursor/skills/` (Kasten unten). |
| Copilot VS Code | Spiegeln nach `.github/skills/` (Kasten unten), dann neuer Chat. Klappt es so, spiegelt ihr ab Ü2 nach jeder Skill-Änderung. |
| Copilot CLI | `/skills reload` |

Spiegeln, nur den Kasten für euer Tool:

```bash
# Codex
cd ../habit-skilltest && mkdir -p .agents && cp -R .claude/skills .agents/
```

```bash
# Cursor
cd ../habit-skilltest && mkdir -p .cursor && cp -R .claude/skills .cursor/
```

```bash
# Copilot in VS Code
cd ../habit-skilltest && mkdir -p .github && cp -R .claude/skills .github/
```

Aufräumen (erst zurück in den Fork-Ordner, sonst steht die Shell danach in einem gelöschten Ordner):

```bash
cd ../habit-tracker-demo
git worktree remove --force ../habit-skilltest
```

### Lese-Frage (Weg A und B)

Agent im Repo starten und eingeben:

```text
Lies das Repo und erkläre in fünf Sätzen:
Was tut die App, wie ist sie aufgebaut,
mit welchen Befehlen prüfe ich eine Änderung? Ändere nichts.
```

## Pro Tool

| Tool | Start im Repo | Woran ihr seht, dass es läuft |
|---|---|---|
| Claude Code | `claude` | Antwort auf die Lese-Frage. Mit `/status` seht ihr Modell und Konto. Version siehe unten. |
| Codex | `codex` | Antwort auf die Lese-Frage. Fragt Codex, ob es dem Ordner vertrauen soll: ja, sonst laden Projekt-Hooks später nicht. Jeden Projekt-Hook gebt ihr zusätzlich einmal über `/hooks` frei (Ü6). |
| Cursor | Repo-Ordner öffnen, Agent-Chat | Antwort im Agent-Modus (nicht Ask). Terminal-Befehle müssen erlaubt sein. |
| Copilot | VS Code: Chat im Agent-Modus, oder `copilot` im Terminal (Copilot CLI) | Antwort im Agent-Modus. Firmenlizenz: Admins müssen Agent-Modus und Terminal erlauben. |

**Claude Code: Version prüfen.** Erst ab 2.1.277 liest Claude Code `AGENTS.md` ohne `CLAUDE.md`. Ab 2.1.283 starten Sessions im Auto-Modus (Blatt Ü1 und Ü4).

```bash
claude --version  # mindestens 2.1.277
claude update  # falls älter und erlaubt
```

Ist die Version in der Firma festgeschrieben und älter? Oder gibt es im Repo schon eine `CLAUDE.md`, `.claude/CLAUDE.md` oder `CLAUDE.local.md`? Dann liest Claude Code `AGENTS.md` nicht von selbst. Ab Ü2 importiert ihr sie mit einer Zeile in der `CLAUDE.md` (`>>` hängt an, eine bestehende Datei bleibt erhalten):

```bash
echo '@AGENTS.md' >> CLAUDE.md
```

Nach einem Update von 2.1.276 oder älter kann die erste Session `AGENTS.md` noch auslassen, ab der nächsten klappt es.

Habt ihr schon persönliche Skills mit den Namen `spec`, `code` oder `verify` (Claude Code: `~/.claude/skills/`)? Die gewinnen gegen die Projekt-Skills. Verschiebt sie für die zwei Tage:

```bash
mkdir -p ~/.claude/skills-geparkt
for s in spec code verify; do
  [ -e ~/.claude/skills/$s ] && mv ~/.claude/skills/$s ~/.claude/skills-geparkt/
done
ls ~/.claude/skills
```

## Gestufte Hilfen

<details>
<summary>Hilfe 1: Wo hakt es meistens?</summary>

- `node -v` zeigt nicht 22: `nvm install 22 && nvm use 22` (bzw. `fnm use 22`). Das Repo verlangt genau Node 22.
- `npm ci` hängt hinter dem Firmen-Proxy: `npm config get registry` prüfen, ggf. die interne Registry setzen. Hilft das nicht: ins Gast-WLAN bzw. Hotspot.
- `gh` nicht eingeloggt: `gh auth login`.
- Port 3110 belegt: `lsof -i :3110` zeigt den Prozess.
- Windows: alles in WSL2 bzw. Git Bash, nicht in PowerShell.

</details>

<details>
<summary>Hilfe 2: Fehlermeldung an den Agenten geben</summary>

Im selben Ordner den Agenten starten und eingeben:

```text
Dieser Befehl schlägt fehl: <Befehl>.
Hier die Ausgabe: <Ausgabe>.
Erkläre die Ursache und schlage den kleinsten Fix vor.
Ändere keine Dateien im Repo.
```

</details>

<details>
<summary>Hilfe 3: Es geht gar nicht</summary>

Eine Person im Raum teilt den Bildschirm, ihr arbeitet zu zweit, bis es bei euch läuft. Parallel dem Kursleiter im globalen Chat schreiben, z. B. „R3: npm ci hängt am Proxy“. Er kommt zuerst zu Setup-Problemen.

</details>

## Rückfall

Wer am Ende von Ü0 kein grünes Setup hat, arbeitet in Ü1 mit einer Person im Raum zusammen (sie teilt den Bildschirm, ihr schreibt die Liste gemeinsam) und löst das Setup in der ersten Pause mit dem Kursleiter.

## Bonus für Schnelle

- E2E einmal laufen lassen (ca. 45 Sekunden, App vorher stoppen):

  ```bash
  PORT=3110 E2E_PORT=3110 npm run test:e2e
  ```

- Issue #1 lesen, ohne Agent: `gh issue view 1`. Was würdet ihr als Entwickler/in zuerst fragen?
- `cat KURS.md` gibt es noch nicht auf `main`. Schaut euch an, was kommt:

  ```bash
  git show origin/stufe/10-verify-pr:KURS.md | head -30
  ```

## Für den Debrief

Kein Debrief im Plenum. Die Debrief-Person postet nur den Raum-Stand in den globalen Chat, aus dem Raum oder gleich nach der Rückkehr, z. B. `R4: 3/4 grün, 1x Proxy-Problem bei npm ci, Weg A 2, Weg B 2`.
