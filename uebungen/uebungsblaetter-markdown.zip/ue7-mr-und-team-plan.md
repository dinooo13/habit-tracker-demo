# Ü7 Harte Regeln: Stop-Hook und Permissions

**Tag 2 · Donnerstag 19.11., zum Abschluss · Zeitbox 40 Minuten**

## Ziel

Was immer passieren muss oder nie passieren darf, steht nicht im Prompt, sondern in der Konfiguration. Der Harness setzt es durch, nicht das Modell. Ihr baut zwei harte Regeln: einen **Stop-Hook**, der am Ende jedes Turns die schnellen Gates fährt und bei Rot blockt. Und **Permissions** nach der Reihenfolge `deny` vor `ask` vor `allow`.

**Done, wenn …**

- [ ] der Stop-Hook `gates-on-stop` in `.claude/settings.json` registriert ist und eure schnellen Gates fährt (Sekunden, kein E2E),
- [ ] ihr ihn **direkt** aufgerufen habt, einmal grün (keine Ausgabe) und einmal rot (`"decision": "block"`),
- [ ] `.claude/settings.json` Permissions hat: `deny` für `.env` und Force-Push, `ask` für `git push`, `allow` für eure Testbefehle,
- [ ] ihr es getestet habt: Der Agent soll eine Dummy-`.env` lesen und wird geblockt. Ein `git push` fragt nach,
- [ ] ihr eine Zeile für die Abschluss-Runde notiert habt (letzter Schritt).

Kann euer Tool keine Hooks, oder sperrt die Firma sie? Dann gilt für den Stop-Hook: dieselben Gates als Git-`pre-commit` oder CI-Job (Hilfe 2).

## Zeitplan

| Min. | Was |
|---|---|
| 0-3 | Blatt lesen |
| 3-15 | Stop-Hook übernehmen, registrieren, direkt testen: grün und rot |
| 15-27 | Permissions in `.claude/settings.json`, neue Session, `.env`- und Push-Test |
| 27-32 | Im Raum vergleichen: Was steht bei euch in `deny`, was in `ask`? |
| 32-35 | Committen, aufräumen (Dummy-`.env` löschen) |
| 35-40 | Mitnehmen: jede Person allein, eine Zeile notieren (letzter Abschnitt) |

Der Kursleiter kommt reihum in die Räume. Wer hängt: erst die gestuften Hilfen unten im Übungsheft, dann die Gruppe, dann dem Kursleiter im globalen Chat schreiben (Raum und ein Satz).

## Weg A: euer Repo

1. **Stop-Hook aus der Vorlage** übernehmen:

   ```bash
   mkdir -p .claude/hooks
   cp ../rheinwerk-starter-skills/.claude/hooks/gates-on-stop.sh .claude/hooks/
   chmod +x .claude/hooks/gates-on-stop.sh
   ```

   Oben in `GATES=( … )` eure schnellen Gates eintragen, ein Befehl pro Zeile, z. B. `"./gradlew spotlessCheck"` oder `"npm run lint"`. Nur Befehle, die in Sekunden laufen, kein E2E. Solange `GATES` leer ist, tut der Hook nichts. Optional `READY_CHECK`, z. B. `[ -d node_modules ]`.
2. **Registrieren:** Habt ihr noch keine `.claude/settings.json`, nehmt die der Vorlage. Sie enthält den `Stop`-Eintrag und ein `deny`-Beispiel:

   ```bash
   cp ../rheinwerk-starter-skills/.claude/settings.json .claude/settings.json
   ```

   Gibt es die Datei schon, nur den `Stop`-Eintrag aus Weg B, Schritt 2 in `hooks` ergänzen.
3. **Direkt testen** wie in Weg B, Schritt 3. Für Rot erst einen Fehler einbauen, den euer erstes Gate findet, dann den Hook aufrufen, danach mit `git checkout -- <datei>` zurück. Ohne Änderung seit dem letzten Lauf endet der Hook sofort grün (siehe Weg B).
4. **Permissions** wie im Abschnitt „Permissions“ unten, mit euren Testbefehlen unter `allow`. Für den Test eine Dummy-Datei `.env.seminar` statt `.env` nehmen, falls ihr schon eine echte `.env` habt. Die Regel `Read(./.env.*)` deckt sie ab.
5. **Nicht pushen.** Ob `settings.json` mit Hook und Permissions ins Firmen-Repo geht, entscheidet euer Team per MR.

## Weg B: Demo-Fork

1. **Stop-Hook übernehmen** aus Stufe 9 und lesen. Er fährt `npm run lint` und `npm test`, nur wenn sich seit seinem letzten Lauf etwas geändert hat. Rot blockt, und `stop_hook_active` verhindert eine Endlosschleife:

   ```bash
   git checkout origin/stufe/09-verify-hook -- .claude/hooks/gates-on-stop.sh
   ```

2. **Registrieren:** `.claude/settings.json` anlegen (auf Stufe 8 gibt es sie noch nicht). Die Permissions kommen in Schritt 4 dazu:

   ```json
   {
     "hooks": {
       "Stop": [
         {
           "hooks": [
             {
               "type": "command",
               "command": "\"${CLAUDE_PROJECT_DIR}\"/.claude/hooks/gates-on-stop.sh",
               "timeout": 180
             }
           ]
         }
       ]
     }
   }
   ```

3. **Direkt testen.** Grün (ca. 15 s, keine Ausgabe heißt grün):

   ```bash
   IN="{\"stop_hook_active\":false,\"cwd\":\"$PWD\"}"
   echo "$IN" | .claude/hooks/gates-on-stop.sh; echo "exit $?"
   ```

   **Wichtig:** Der Hook läuft nur, wenn sich seit seinem letzten Lauf etwas geändert hat. Ohne Änderung endet er sofort mit Exit 0, **auch wenn die Gates rot wären**. Für den Rot-Test deshalb zuerst eine Lint-Verletzung einbauen, z. B. `const unused = 1` in einer `.ts`-Datei, dann den Direktaufruf, danach zurücksetzen. Erwartet: `"decision": "block"` mit den Fehlerzeilen.

   ```bash
   echo 'const unused = 1' >> app/utils/domain/date.ts
   IN="{\"stop_hook_active\":false,\"cwd\":\"$PWD\"}"
   echo "$IN" | .claude/hooks/gates-on-stop.sh
   git checkout -- app
   ```

   Zum erneuten Testen ohne Änderung den Merker löschen:

   ```bash
   rm -f "$(git rev-parse --git-path claude-gates-on-stop)"
   ```

4. **Permissions** wie im Abschnitt „Permissions“ unten in dieselbe `.claude/settings.json`. Prüfen, ob das JSON gültig ist:

   ```bash
   node -e 'JSON.parse(require("fs").readFileSync(".claude/settings.json"))' \
     && echo ok
   ```

5. **Trust:** `claude` im Repo einmal interaktiv starten und dem Ordner vertrauen. Ohne bestätigten Trust ignoriert Claude Code die `allow`-Einträge aus `.claude/settings.json` (Meldung „Ignoring … permissions.allow entries … workspace has not been trusted“). `deny` und `ask` greifen trotzdem.
6. Neue Session, `/hooks` zeigt den `Stop`-Eintrag, `/permissions` die Regeln. Dann die zwei Tests aus „Permissions“.
7. Committen:

   ```bash
   git add .claude/hooks .claude/settings.json
   git commit -m "feat(claude): add the stop hook and permissions"
   ```

## Permissions: `deny` vor `ask` vor `allow`

Claude Code prüft die Regeln in dieser Reihenfolge. Trifft `deny`, ist Schluss, auch wenn eine `allow`-Regel passen würde. Trifft `ask`, fragt Claude Code nach. Nur was `allow` erlaubt und nichts davor sperrt, läuft ohne Frage. Beispiel für den Demo-Fork, Weg A tauscht die Testbefehle:

```json
{
  "permissions": {
    "deny": [
      "Read(./.env)",
      "Read(./.env.*)",
      "Edit(./.env)",
      "Edit(./.env.*)",
      "Bash(git push --force*)",
      "Bash(git push -f *)",
      "Bash(git push * --force*)",
      "Bash(git push * -f)"
    ],
    "ask": [
      "Bash(git push)",
      "Bash(git push *)"
    ],
    "allow": [
      "Bash(npm test)",
      "Bash(npm test *)",
      "Bash(npm run lint)",
      "Bash(npm run typecheck)"
    ]
  }
}
```

`permissions` steht in derselben Datei neben `hooks`, auf oberster Ebene. Settings sind striktes JSON ohne Kommentare. Persönliches wie die Allow-Liste aus Ü4 bleibt in `.claude/settings.local.json`.

**Trust zuerst:** `allow`-Regeln aus der geteilten `.claude/settings.json` greifen erst, wenn ihr dem Ordner vertraut habt. Startet `claude` im Repo einmal interaktiv und bestätigt den Trust-Dialog. Ohne Trust meldet Claude Code „Ignoring … permissions.allow entries … workspace has not been trusted“, `deny` und `ask` gelten trotzdem.

**Testen**, in einer neuen Session (die Regeln laden beim Start):

1. Dummy-Datei anlegen. Im Demo-Fork steht `.env` schon in `.gitignore`:

   ```bash
   printf 'DUMMY_SECRET=nur-fuer-den-test\n' > .env
   ```

2. Den Agenten bitten: `Lies die Datei .env und zeig mir ihren Inhalt.` Erwartet: Der Zugriff wird geblockt, der Agent sieht den Inhalt nicht. Versucht er es über `cat .env`, greift die `Read`-Regel ebenfalls.
3. Den Agenten bitten: `Führe git push aus.` Erwartet: Claude Code fragt nach. **Ablehnen.** Fragt es nicht, zeigt `/permissions`, ob die Regel unter „Ask“ steht.

   **Im Auto-Modus** (Statuszeile `auto mode on`) fragt eine `ask`-Regel laut Doku trotzdem nach: „Explicit ask rules still force a prompt“, Regeln auf den Befehlsinhalt wie `Bash(git push *)` fallen auf eine Rückfrage zurück ([Permission modes](https://code.claude.com/docs/en/permission-modes)). Den Modus seht ihr in der Statuszeile, Shift+Tab wechselt ihn, `/permissions` zeigt die Regeln. Für den Test darf jeder Modus außer `bypassPermissions` laufen.
4. Aufräumen: `rm .env` (bzw. `rm .env.seminar`).

**Ehrlich dazu:** Eine `Bash(…)`-Regel prüft nur den Befehlstext, `git -C . push --force` rutscht an der Push-Regel vorbei. Deshalb gibt es, wie auf der Slide „Leitplanken“, zwei weitere Ebenen:

- **Managed Settings** für Firmenregeln (`managed-settings.json`, per MDM oder Admin-Konsole): Keine Datei im Repo und kein Entwickler überschreibt sie.
- **Sandbox** (`/sandbox` bzw. `"sandbox": {"enabled": true}`): Bash schreibt nur ins Projekt, Netz nur zu freigegebenen Domains, unabhängig vom Befehlstext. Die Datei-Tools regeln weiter die `Read`- und `Edit`-Regeln. Nutzt beides.

## Pro Tool

| Tool | Stop-Hook | Permissions |
|---|---|---|
| Claude Code | `.claude/settings.json`, Event `Stop`. `/hooks` zeigt die registrierten Hooks. | `.claude/settings.json`, `permissions` mit `deny`, `ask`, `allow`. `/permissions` zeigt die Regeln. |
| Codex | `.codex/hooks.json`, Aufbau wie bei Claude Code (Event → Command). `Stop` mit `{"decision":"block","reason":…}` lässt Codex weiterarbeiten. Projekt-Hooks laden nur, wenn ihr dem Ordner vertraut **und** den Hook einmal über `/hooks` freigebt. Verlasst euch nicht auf `${CLAUDE_PROJECT_DIR}`, gebt den Pfad relativ zum Repo-Root an. | Sandbox-Modus und Approval-Modus (`/permissions`): wohin Codex schreiben darf und wann es fragt. Eine Sperre für einzelne Dateien wie `.env`: siehe Doku eures Tools. |
| Cursor | Liest die Claude-Hooks aus `.claude/settings.json` mit (Einstellung „Include Third-Party Plugins, Skills, and Other Configs“, Standard an). Nativ: `.cursor/hooks.json` mit `"version": 1`, Event `stop`. | Auto-Run für Terminal-Befehle nur mit Allowlist, sonst fragt Cursor pro Befehl. Dateien sperren: siehe Doku eures Tools. |
| Copilot | Copilot CLI und VS Code (Preview) lesen `.github/hooks/*.json` und `.claude/settings.json`. In der CLI blockt `Stop` bzw. `agentStop` mit `{"decision":"block",…}`. VS Code: siehe Doku. | VS Code: Freigaben bzw. Auto-Approve für Terminal-Befehle. CLI: Freigaben pro Tool beim Start. Dateien sperren: siehe Doku eures Tools. |

Für alle gilt: Ein Hook ist ein Shell-Skript. Testet es immer zuerst direkt mit `echo '{…}' | skript.sh`, bevor ihr es dem Agenten unterschiebt.

## Gestufte Hilfen

<details>
<summary>Hilfe 1: Denkanstoß</summary>

- Kontext-Datei und Skill sind **beratend**, der Agent kann sie übersehen. Hook und Permissions sind **Konfiguration**: Der Harness setzt sie durch. Faustregel: Was ihr schon zweimal in `AGENTS.md` „bitte denk daran“ geschrieben habt, gehört in einen Hook oder in `deny`.
- Stop-Hooks brauchen einen Schleifenschutz: Ist `stop_hook_active` true, arbeitet der Agent schon wegen des Hooks weiter. Dann nicht noch einmal blocken.
- Der Stop-Hook fährt nur schnelle Gates. E2E dauert Minuten und gehört in `/verify` und die CI.
- `deny` für alles, was nie passieren darf. `ask` für alles, was ein Mensch bewusst auslösen soll. `allow` nur für Befehle, die nichts kaputt machen können.

</details>

<details>
<summary>Hilfe 2: Hooks gesperrt? Dieselben Gates in Git und CI</summary>

**Git-`pre-commit`**, lokal in `.git/hooks/pre-commit` (nicht versioniert; im Team über `core.hooksPath`, lefthook oder husky). Weg B, Weg A tauscht die Befehle:

```bash
#!/usr/bin/env bash
# pre-commit: die schnellen Gates vor jedem Commit, ohne Agent.
npm run --silent lint && npm test --silent || {
  echo "pre-commit: Gates rot."; exit 1; }
```

```bash
chmod +x .git/hooks/pre-commit
```


**CI-Job: dieselben Gates vor dem Merge.** Die Snippets fahren die Gates des Demo-Repos (wie `.github/workflows/ci.yml` auf `origin/stufe/10-verify-pr`, dort mit Build und Caching). Weg A: `image` bzw. `setup-node` und die Befehle tauschen, z. B. `eclipse-temurin:21` und `./gradlew spotlessCheck test`.

**YAML braucht die Einrückung.** Beim Kopieren aus dem PDF geht sie **immer** verloren. Kopiert YAML nur aus dem Markdown-Zip (`uebungsblaetter-markdown.zip`, Datei `ue7-mr-und-team-plan.md`). Doch aus dem PDF kopiert? Dann den Agenten reparieren lassen (`Rücke diese Datei als gültiges YAML ein, ändere sonst nichts.`) und prüfen: GitLab `glab ci lint`, GitHub `actionlint`.

GitLab, `.gitlab-ci.yml`. Der Job `schema-guard` ist die Regel aus Bonus 1 (Guard-Vorlage): Er läuft nur, wenn eine riskante Datei im MR geändert ist.

```yaml
# .gitlab-ci.yml: dieselben Gates wie lokal, für jeden MR und den Default-Branch
workflow:
  rules:
    - if: $CI_PIPELINE_SOURCE == "merge_request_event"
    - if: $CI_COMMIT_BRANCH == $CI_DEFAULT_BRANCH

default:
  image: node:22
  cache:
    key: { files: [package-lock.json] }
    paths: [.npm/]
  before_script:
    - npm ci --cache .npm --prefer-offline

gates:
  stage: test
  script:
    - npm run lint
    - npm run typecheck
    - npm test

e2e:
  stage: test
  variables: { PORT: "3110", E2E_PORT: "3110" }
  script:
    - npx playwright install --with-deps chromium
    - npm run test:e2e

# Die Guard-Regel als eigener Job: nur, wenn eine riskante Datei geändert ist.
schema-guard:
  stage: test
  rules:
    - changes:
        - app/types/app-data.ts
        - app/utils/persistence/storage-schema.ts
  script:
    - npx vitest run --project unit storage-schema schema-migrations pause-mode
```

Pflicht vor dem Merge: in GitLab unter Settings → Merge requests → Merge checks „Pipelines must succeed“ aktivieren.

GitHub Actions, `.github/workflows/gates.yml`. Die Schema-Tests stecken hier schon in `npm test`:

```yaml
# .github/workflows/gates.yml: dieselben Gates wie lokal, für jeden PR
name: Gates
on:
  pull_request:
  push:
    branches: [main]
permissions:
  contents: read
jobs:
  gates:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v6
      - uses: actions/setup-node@v6
        with: { node-version: 22, cache: npm }
      - run: npm ci
      - run: npm run lint
      - run: npm run typecheck
      - run: npm test
  e2e:
    runs-on: ubuntu-latest
    env: { PORT: 3110, E2E_PORT: 3110 }
    steps:
      - uses: actions/checkout@v6
      - uses: actions/setup-node@v6
        with: { node-version: 22, cache: npm }
      - run: npm ci
      - run: npx playwright install --with-deps chromium
      - run: npm run test:e2e
```

Pflicht vor dem Merge: unter Settings → Rules → Rulesets (oder Branch protection) für `main` „Require status checks to pass“ mit den Checks `gates` und `e2e`.

</details>

<details>
<summary>Hilfe 3: Musterlösung ansehen</summary>

```bash
B=origin/seminar/ue7-stop-hook-permissions
git diff --stat origin/stufe/08-verify-browser $B
git show $B:.claude/settings.json
git show $B:.claude/hooks/gates-on-stop.sh
```

Weg A: `.claude/hooks/gates-on-stop.sh`, `.claude/settings.json` und der Abschnitt „Leitplanken“ im README der Vorlage.

</details>

## Rückfall

Weg B: Stop-Hook und Permissions aus der Musterlösung holen:

```bash
B=origin/seminar/ue7-stop-hook-permissions
git checkout $B -- .claude/hooks/gates-on-stop.sh .claude/settings.json
git commit -m "feat(claude): stop hook and permissions (Musterlösung)"
```

Den Direktaufruf (grün und rot) und die zwei Permissions-Tests macht ihr trotzdem selbst, sie sind Teil von Done.

Weg A: Minimum ist der Permissions-Block aus der Vorlage mit euren Testbefehlen unter `allow`, getestet mit der Dummy-Datei. Den Stop-Hook füllt ihr, wenn eure schnellen Gates feststehen.

## Bonus für Schnelle

### Bonus 1: Guard für eine riskante Datei

Ein zweiter Hook, `PostToolUse` statt `Stop`: Ändert der Agent eine riskante Datei (Migration, OpenAPI-Spec, Datenmodell), läuft sofort ein schneller Test. Bauen nach dem Blatt [Guard-Vorlage](guard-vorlage.md), Abschnitte 1 bis 4. Den `PostToolUse`-Eintrag ergänzt ihr in `hooks` neben `Stop`, nicht als neue Datei. Weg B, danach als Vergleich die Musterlösung:

```bash
git show origin/stufe/09-verify-hook:.claude/hooks/schema-guard.sh
```

### Bonus 2: Quick-Skill

Ein Skill `quick` für kleine Aufgaben: `/quick <Aufgabe oder Ticket>` fährt den ganzen Flow in einer Session, mit der Freigabe als einzigem Halt. **Ehrlich dazu:** ein ungetesteter Bonus, ein echter Lauf steht noch aus.

1. In der Hauptsession ein kurzes Interview mit euch.
2. `/spec` in Kurzform: kurze Spec, wenige Tasks.
3. **Stopp, bis ihr freigebt.** Freigabe wie im Seminar: `Status: approved · Approved-by: <Name>`, committet als `docs(spec): approve <slug>`.
4. Ein frischer Subagent führt `/code specs/<slug>.md` aus.
5. Ein weiterer frischer Subagent führt `/verify specs/<slug>.md` aus.
6. Am Ende fasst `quick` das Gesamturteil zusammen.

Damit `quick` die anderen Skills aufrufen kann, entfernt ihr `disable-model-invocation: true` aus `spec`, `code` und `verify` (im Demo-Fork hat `spec` das Flag schon nicht). **Der Preis:** Der Agent kann diese Skills dann auch von sich aus starten. Wer das nicht will, lässt das Flag stehen und ruft weiter von Hand auf.

Weg B, Musterlösung:

```bash
Q=origin/seminar/ue7-quick-skill
git show $Q:.claude/skills/quick/SKILL.md
git diff origin/seminar/ue7-stop-hook-permissions $Q -- .claude/skills
```

<details>
<summary>Gerüst: .claude/skills/quick/SKILL.md</summary>

```markdown
---
name: quick
description: Run the whole flow for a small task or ticket in one session. Short
  interview, short spec via /spec, stop for human approval, then /code and /verify
  each in a fresh subagent. Use when the user types /quick.
argument-hint: "[issue-number | task description]"
disable-model-invocation: true
---

# Quick

Take this task through spec, code and verify: **$ARGUMENTS**

You orchestrate. You write no production code yourself.

## 1. Interview
- Ask at most three short questions about scope, acceptance and edge cases.
- If the argument is an issue number, read it first (`gh issue view <n>`).

## 2. Short spec
- Run `/spec` with the task and the answers. Ask for a short spec:
  few acceptance criteria, at most five tasks.

## 3. Stop for approval
- Show the spec path and a five-line summary. Then **stop and wait**.
- Only the human approves. When they do, set the header to
  `Status: approved  ·  Approved-by: <name>, <YYYY-MM-DD>` and commit only the
  spec: `docs(spec): approve <slug>`. Never approve on your own.

## 4. Code in a fresh subagent
- Start one new subagent (Agent tool) with only this prompt:
  `Run /code specs/<slug>.md and report branch, commits and gate results.`
- Do not pass this conversation. The spec is the context.

## 5. Verify in a fresh subagent
- Start another new subagent with only:
  `Run /verify specs/<slug>.md and report the verdict and the report path.`

## 6. Report
- Overall verdict (Pass or Issues found), branch, commits, report path,
  open findings. Do not push, open a PR or merge.
```

`quick` selbst behält das Flag: Den ganzen Flow startet ihr bewusst von Hand.

</details>

### Weitere Ideen

- Stop-Hook im echten Lauf: neue Session, `Füge in app/utils/domain/date.ts eine ungenutzte Variable ein und beende den Turn.` Was macht der Hook?
- Weitere `deny`-Regeln für euer Team: Deploy-Befehle, Prod-Zugänge, weitere Secret-Pfade.

## Mitnehmen: eure Zeile für die Abschluss-Runde

Fünf Minuten, jede Person allein. Beantwortet für euch:

**Was nehmt ihr aus dem Seminar mit in euer Projekt, und worauf freut ihr euch beim Anwenden?**

Notiert eine Zeile. Das ist euer Beitrag zur Abschluss-Runde im Plenum.

Wer den Flow im Team einführen will: Die [Team-Plan-Vorlage](team-plan-vorlage.md) und ein [ausgefülltes Beispiel](team-plan-beispiel.md) liegen als Material zum Mitnehmen im Heft. Den Draft-PR mit `/verify … --pr` probiert ihr zu Hause, siehe Hausaufgabe.

## Für den Debrief

Leitfrage: **Welche Regel steht jetzt in der Konfiguration statt im Prompt?**

- In der Abschluss-Runde: eure Zeile aus „Mitnehmen“.
- Im Plenum zeigt der Kursleiter den Stop-Hook rot und eine geblockte `.env`.
- Hausaufgabe: Weg B Issue #3 und #4 mit dem fertigen Flow, dazu der Draft-PR mit `/verify … --pr` (siehe `KURS.md` auf `origin/stufe/10-verify-pr`). Weg A: ein erstes echtes Ticket mit `/spec`, `/code` und `/verify`.
