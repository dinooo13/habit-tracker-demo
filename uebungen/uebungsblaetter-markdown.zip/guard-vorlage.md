# Guard-Vorlage: eine harte Regel als Hook

**Für Ü7, Bonus 1 (Weg A und Weg B) · stack-neutral, Bash**

Ein Guard ist ein kleines Skript. Der Agent ändert eine riskante Datei, der Harness ruft das Skript auf, das Skript fährt einen Test. Rot geht als `block` mit den Fehlerzeilen zurück an den Agenten. Das ist deterministisch: Es passiert jedes Mal, egal was im Prompt steht.

Ihr baut den Guard selbst und könnt danach jede Zeile erklären. Die Hooks aus `origin/stufe/09-verify-hook` (`schema-guard.sh`, `gates-on-stop.sh`) sind nur Musterlösung und Rückfall.

## 1. Regel wählen

Welche Datei bricht bei euch immer wieder, und welcher schnelle Test merkt es? Beispiele, Befehle an euren Stack anpassen:

| Riskante Datei | Muster in `PATTERNS` | Schneller Test in `CHECK` |
|---|---|---|
| Demo-Fork: Datenmodell und Zod-Schema | `'*/app/types/app-data.ts'`, `'*/app/utils/persistence/storage-schema.ts'` | `npx vitest run --project unit storage-schema schema-migrations pause-mode` |
| DB-Migration (Flyway, Liquibase) | `'*/src/main/resources/db/migration/*'` | `./gradlew test --tests '*Migration*'` bzw. `mvn -q test -Dtest='*Migration*'` |
| OpenAPI-Vertrag | `'*/api/openapi.yaml'` | euer Contract- bzw. Lint-Befehl, z. B. `npx @redocly/cli lint api/openapi.yaml` |
| Übersetzungen | `'*/src/locales/*.json'` | euer i18n-Check, z. B. `npm run i18n:check` |
| Generierter Client | `'*/src/generated/*'` | Generator laufen lassen und `git diff --exit-code` |

Faustregel: Der Test dauert Sekunden. Er läuft nach **jeder** Änderung an der Datei. Ein Test, der zwei Minuten braucht, gehört in den Stop-Hook oder in die CI.

## 2. Das Skript

Datei `.claude/hooks/file-guard.sh` anlegen und nur den Block `<ANPASSEN>` ändern. Die Werte unten passen für den Demo-Fork. Das Skript steht in **zwei Kästen**, damit im PDF keiner über einen Seitenumbruch läuft: Teil 1 und Teil 2 nacheinander in dieselbe Datei kopieren.

**Teil 1** (Einstellungen, Pfad lesen, Muster prüfen):

```bash
#!/usr/bin/env bash
# file-guard.sh: PostToolUse-Hook (Matcher Edit|Write).
# Ändert der Agent eine riskante Datei, läuft ein schneller Testbefehl.
# Grün: kurze Meldung. Rot: {"decision":"block","reason":...} mit den Fehlern.
# Jede andere Datei: sofort Exit 0, keine Ausgabe.
set -uo pipefail

# ---- <ANPASSEN> -----------------------------------------------------------
# Riskante Dateien als Shell-Muster wie bei case. Der Pfad kommt absolut an,
# deshalb beginnt jedes Muster mit */
PATTERNS=(
  '*/app/types/app-data.ts'
  '*/app/utils/persistence/storage-schema.ts'
)
# Schneller Testbefehl (Sekunden, nicht Minuten). Läuft im Repo-Root.
CHECK='npx vitest run --project unit storage-schema schema-migrations pause-mode'
# ---------------------------------------------------------------------------

input="$(cat)"

# 1. Pfad aus dem Hook-JSON lesen: jq, sonst python3, sonst node.
#    Claude Code: tool_input.file_path. Cursor (afterFileEdit): file_path.
if command -v jq >/dev/null 2>&1; then
  file="$(printf '%s' "$input" |
    jq -r '.tool_input.file_path // .file_path // empty' 2>/dev/null)"
elif command -v python3 >/dev/null 2>&1; then
  file="$(printf '%s' "$input" | python3 -c '
import json, sys
d = json.load(sys.stdin)
t = d.get("tool_input") or {}
print(t.get("file_path") or d.get("file_path") or "")' 2>/dev/null)"
else
  file="$(printf '%s' "$input" | node -e '
let s = ""
process.stdin.on("data", (c) => (s += c)).on("end", () => {
  try { const d = JSON.parse(s)
    process.stdout.write(d.tool_input?.file_path ?? d.file_path ?? "") } catch {}
})' 2>/dev/null)"
fi
[ -n "$file" ] || exit 0

# 2. Nur riskante Dateien prüfen.
hit=""
for p in "${PATTERNS[@]}"; do
  # shellcheck disable=SC2254
  case "$file" in $p) hit=1; break ;; esac
done
[ -n "$hit" ] || exit 0
```

**Teil 2** (direkt darunter anhängen: Test fahren, Ergebnis melden):

```bash
# 3. Im Repo der Datei arbeiten (klappt auch in Worktrees).
root="$(git -C "$(dirname "$file")" rev-parse --show-toplevel 2>/dev/null)"
cd "${root:-${CLAUDE_PROJECT_DIR:-$PWD}}" || exit 0

# 4. Ergebnis als JSON ausgeben. $1 = block | ok, $2 = Text
emit() {
  if command -v jq >/dev/null 2>&1; then
    if [ "$1" = block ]; then jq -n --arg r "$2" '{decision: "block", reason: $r}'
    else jq -n --arg m "$2" '{systemMessage: $m}'; fi
  elif command -v python3 >/dev/null 2>&1; then
    MODE="$1" TEXT="$2" python3 -c '
import json, os
t, m = os.environ["TEXT"], os.environ["MODE"]
o = {"decision": "block", "reason": t} if m == "block" else {"systemMessage": t}
print(json.dumps(o, ensure_ascii=False))'
  else
    MODE="$1" TEXT="$2" node -e '
const { MODE: m, TEXT: t } = process.env
const o = m === "block" ? { decision: "block", reason: t } : { systemMessage: t }
console.log(JSON.stringify(o))'
  fi
}

# 5. Testbefehl fahren.
rel="${file#"$PWD"/}"
if out="$(NO_COLOR=1 bash -c "$CHECK" 2>&1)"; then
  emit ok "file-guard: $rel geändert, Tests grün"
else
  emit block "Tests rot nach Änderung an $rel. Behebe die Ursache, schwäche keinen
Test ab. Befehl: $CHECK
$(printf '%s\n' "$out" | tail -n 30)"
fi
exit 0
```

Was die Teile tun:

- **Schritt 1** liest den Dateipfad aus dem JSON, das der Harness auf stdin schickt. `jq` ist optional, sonst übernimmt `python3` oder `node`.
- **Schritt 2** vergleicht den Pfad mit euren Mustern. Kein Treffer: Ende ohne Ausgabe, das kostet Millisekunden.
- **Schritt 3** wechselt ins Repo der Datei. Das klappt auch in einem Worktree.
- **Schritt 4 und 5** fahren den Test. Grün gibt eine `systemMessage` für euch aus. Rot gibt `{"decision": "block", "reason": …}` aus, der Agent liest den Grund und die letzten 30 Zeilen des Testlaufs.
- Das Skript endet immer mit Exit 0. Die Entscheidung steckt im JSON, nicht im Exit-Code.

Aus dem PDF kopiert? Einrückung ist egal. Prüft danach, dass beide Teile drin sind und die Syntax stimmt:

```bash
chmod +x .claude/hooks/file-guard.sh
grep -c 'emit ok' .claude/hooks/file-guard.sh  # 1 (Teil 2 ist drin)
bash -n .claude/hooks/file-guard.sh && echo "Syntax ok"
```

## 3. Registrieren (Claude Code)

In `.claude/settings.json` (gilt für alle im Repo, wird committet). Gibt es die Datei schon, nur den `PostToolUse`-Eintrag in `hooks` ergänzen:

```json
{
  "hooks": {
    "PostToolUse": [
      {
        "matcher": "Edit|Write",
        "hooks": [
          {
            "type": "command",
            "command": "\"${CLAUDE_PROJECT_DIR}\"/.claude/hooks/file-guard.sh",
            "timeout": 120
          }
        ]
      }
    ]
  }
}
```

Neue Session starten, `/hooks` zeigt den Eintrag. `timeout` ist in Sekunden, setzt ihn größer als die Laufzeit eures Tests.

Andere Tools, Stand Doku vom 17.11.2026:

| Tool | Registrieren | Eingabe |
|---|---|---|
| Cursor | liest `.claude/settings.json` mit (Einstellung „Include Third-Party Plugins, Skills, and Other Configs“). Nativ: `.cursor/hooks.json`, Event `afterFileEdit` | nativ steht `file_path` oben im JSON, das Skript liest beides |
| Codex | `.codex/hooks.json`. Lädt nur in einem vertrauten Ordner und nach einmaliger Freigabe über `/hooks` (nach jeder Änderung erneut) | Dateiänderungen laufen über `apply_patch`, ein Dateipfad im Hook-Input ist nicht dokumentiert. Nehmt `pre-commit` oder CI (Abschnitt 5). |
| Copilot | `.github/hooks/*.json`, die Copilot CLI liest auch `.claude/settings.json` | Events in camelCase (`postToolUse`) liefern die Argumente als `toolArgs`, Events in PascalCase (`PostToolUse`) als `tool_input`. Feldnamen der Edit-Tools in der Doku prüfen, ggf. Schritt 1 anpassen. |

## 4. Direkt testen: grün, rot, neutral

Immer erst direkt aufrufen, dann dem Agenten unterschieben. Befehle für den Demo-Fork, im Repo-Root. Weg A: Pfad und Änderung für eure Datei einsetzen.

Grün (ca. 3 s). Erwartet: `"systemMessage": "file-guard: … Tests grün"`.

```bash
F="$PWD/app/utils/persistence/storage-schema.ts"
echo "{\"tool_input\":{\"file_path\":\"$F\"}}" | .claude/hooks/file-guard.sh
```

Rot: die V1-Migration kaputt machen, denselben Aufruf wiederholen. Erwartet: `"decision": "block"` und im `reason` eine Zeile wie `Tests  6 failed`.

```bash
F="$PWD/app/utils/persistence/storage-schema.ts"
perl -pi -e 's/\.\.\.habit, pauses: \[\]/...habit/' "$F"
git diff --stat
echo "{\"tool_input\":{\"file_path\":\"$F\"}}" | .claude/hooks/file-guard.sh
git checkout -- app
```

Neutral: eine andere Datei. Erwartet: keine Ausgabe, Exit 0.

```bash
IN="{\"tool_input\":{\"file_path\":\"$PWD/README.md\"}}"
echo "$IN" | .claude/hooks/file-guard.sh; echo "exit $?"
```

Im echten Lauf: neue Session, `Entferne in migrateToV2 in app/utils/persistence/storage-schema.ts das pauses: []`. Der Agent bekommt den Block mit den roten Tests. Danach `git checkout -- app`.

## 5. Ohne Agent-Hook: dieselbe Regel tool-neutral

Sperrt eure Firma Agent-Hooks, oder kann euer Tool keine? Dann läuft derselbe Guard als Git-Hook und in der CI.

**Git-`pre-commit`**, nutzt das Skript von oben weiter. Lokal in `.git/hooks/pre-commit` (nicht versioniert; im Team über `core.hooksPath`, lefthook oder husky):

```bash
#!/usr/bin/env bash
# pre-commit: derselbe Guard, ohne Agent. Prüft die gestagten Dateien.
root="$(git rev-parse --show-toplevel)"
guard="$root/.claude/hooks/file-guard.sh"
for f in $(git diff --cached --name-only --diff-filter=ACM); do
  out="$(printf '{"tool_input":{"file_path":"%s"}}' "$root/$f" | "$guard")"
  [ -z "$out" ] && continue  # keine riskante Datei
  case "$out" in
    *'"block"'*) printf '%s\n' "$out"; echo "pre-commit: Guard rot."; exit 1 ;;
    *) exit 0 ;;  # einmal grün reicht
  esac
done
exit 0
```

```bash
chmod +x .git/hooks/pre-commit
```

Test: riskante Datei kaputt machen, `git add` und `git commit` bricht mit „pre-commit: Guard rot.“ ab. Ein Commit ohne riskante Datei geht durch.

**CI**: Die Snippets für GitLab und GitHub Actions stehen auf Blatt Ü7, Hilfe 2. In GitLab läuft der Guard dort als eigener Job mit `rules: changes:`. Er startet nur, wenn eine riskante Datei im MR geändert ist.

## Wenn es nicht klappt

- **Keine Ausgabe bei der riskanten Datei:** Muster prüfen. Der Pfad kommt absolut an, also `*/pfad/datei`, nicht `pfad/datei`.
- **Rot, obwohl die Tests von Hand grün sind:** Der Befehl läuft im Repo-Root. Von Hand testen, `<CHECK>` durch euren Testbefehl ersetzen:

  ```bash
  cd "$(git rev-parse --show-toplevel)" && <CHECK>
  ```

- **Hook greift im Agenten nicht:** neue Session, `/hooks` prüfen, `chmod +x` vergessen? Codex: Hook in `/hooks` freigeben.
- **Windows:** Git Bash oder WSL2, nicht PowerShell.
- **Musterlösung ansehen** im Fork (95 Zeilen, mit Hinweis auf den Skill `schema-change`):

  ```bash
  git show origin/stufe/09-verify-hook:.claude/hooks/schema-guard.sh
  ```
