# Übungsblätter: Seminar „Spec-Driven Development mit KI-Coding-Agenten“

Rheinwerk Verlag · online · 18. und 19.11.2026, je 09:00-17:00

Ihr baut in zwei Tagen euren eigenen Flow `/spec` → `/code` → `/verify`, Schicht für Schicht, bis zu harten Regeln in Hook und Permissions. Jede Übung läuft im Breakout-Room. Jede und jeder baut am eigenen Rechner, im eigenen Repo. Der Raum ist zum Helfen und für freiwilliges Vergleichen da. Kein Done-Kriterium hängt davon ab, dass jemand anderes etwas teilt.

Dieses Übungsheft gibt es als Gesamt-PDF und als Einzel-PDF pro Blatt. Verweise wie „Blatt Ü3“ meinen das jeweilige Blatt in diesem Heft. **Aus dem PDF nur Befehle aus den grauen Kästen kopieren; Inline-Befehle im Text aus dem Markdown-Zip (`uebungsblaetter-markdown.zip`).** In den Kästen sind lange Befehle mit `\` umbrochen und bleiben so kopierbar. Befehle im Fließtext und in Tabellen brechen im PDF um und zerfallen beim Kopieren. Im Zip bleiben außerdem Zeilen und Einrückung (wichtig für YAML) erhalten. Den Stand des Hefts zeigt die Fußzeile jeder Seite.

## Die Übungen

| Ü | Tag | Zeitbox | Ziel (Done) | Blatt |
|---|---|---|---|---|
| 0 | Mi 18.11. | 30 Min. | Euer Schnelltest ist grün, euer Tool bietet `/spec` an | [Blatt Ü0](ue0-ankommen.md) |
| 1 | Mi 18.11. | 60 Min. | Ein freier Lauf und eine Liste „Was der Agent nicht wusste“ (mind. 5 Punkte, je mit Datei oder Regel) | [Blatt Ü1](ue1-freier-prompt.md) |
| 2 | Mi 18.11. | 70 Min. | Kurze `AGENTS.md` und ein minimaler `spec`-Skill, der auf dem Ticket eine Spec-Datei schreibt | [Blatt Ü2](ue2-kontext-und-spec-skill.md) |
| 3 | Mi 18.11. | 65 Min. | Spec-Skill v2 und eine Spec, die **ihr selbst** mit der Checkliste geprüft und freigegeben habt, committet | [Blatt Ü3](ue3-spec-voll-und-freigabe.md) |
| 4 | Do 19.11. | 65 Min. | `code`-Skill (TDD, ein Commit pro Task, unabhängige Tasks parallel in Subagenten, Gates) und ein `/code`-Lauf: alle Tasks committet, Gates grün | [Blatt Ü4](ue4-code.md) |
| 5 | Do 19.11. | 60 Min. | `verify`-Skill v1: Gates inkl. E2E, Beleg pro Akzeptanzkriterium, Bericht mit Gesamturteil und Fix-Liste, die `/code` abarbeitet | [Blatt Ü5](ue5-verify-gates.md) |
| 6 | Do 19.11. | 70 Min. | Review-Subagent in `verify`, einmal geprüft, und ein Browser-Check in `verify`, einmal gelaufen, mit Ergebnis im Bericht | [Blatt Ü6](ue6-review-und-hook.md) |
| 7 | Do 19.11. | 40 Min. | Harte Regeln: Stop-Hook mit den schnellen Gates (grün und rot getestet) und Permissions `deny` vor `ask` vor `allow` (`.env` geblockt, `git push` fragt) | [Blatt Ü7](ue7-mr-und-team-plan.md) |

Dazu im Heft: [Guard-Vorlage](guard-vorlage.md) für den Bonus in Ü7, [Team-Plan-Vorlage](team-plan-vorlage.md) und ein [ausgefülltes Beispiel](team-plan-beispiel.md) als Material zum Mitnehmen.

Jedes Blatt hat dieselbe Reihenfolge: Ziel und Done, Zeitplan, Weg A, Weg B, Pro Tool, gestufte Hilfen, Rückfall, Bonus, Debrief.

## So arbeitet ihr im Breakout-Room

- **Laufzeit.** Jeder Raum hat eine feste Laufzeit mit etwas Puffer. Die Rückkehrzeit sagt der Kursleiter beim Öffnen an. Ihr kommt zurück, wenn die Zeit um ist oder wenn ihr fertig seid.
- **Drei Rollen, wechseln pro Übung.** *Zeit* achtet auf die Zeitbox und ruft „noch 10 Minuten“. *Bildschirm*: Wer mag, zeigt zuerst, wenn ihr vergleicht. *Debrief* notiert am Ende ein Ergebnis und eine Frage und postet beides in den **globalen Chat**, aus dem Raum oder gleich nach der Rückkehr.
- **Kein Status-Posten.** Der Kursleiter kommt reihum in die Räume.
- **Zeigen im Debrief:** Der Kursleiter fragt beim Rundgang, wer bei euch präsentiert. Die Räume kommen der Reihe nach dran. Gezeigt wird das Ergebnis, der Kursleiter stellt die Fragen. Zeigt niemand, zeigt er die Musterlösung.
- **Hilfe holen in dieser Reihenfolge:** erst die gestuften Hilfen auf dem Blatt, dann die Gruppe, dann dem Kursleiter im **globalen Chat** schreiben, z. B. „R3: <ein Satz>“. Der globale Chat ist auch aus dem Raum erreichbar.
- **Vertraulichkeit.** Im Raum sitzen Leute anderer Firmen. Wer Weg A geht, teilt nur, was er zeigen darf, z. B. die Spec ohne Code oder nur die Skill-Dateien. Ihr entscheidet.
- **Lange Agentenläufe** (`/code`, `/verify`) laufen, während ihr vergleicht. Startet sie nie direkt vor einer Pause: Rückfragen des Agenten bleiben sonst liegen.

## Weg A oder Weg B

| | Weg A: euer Repo | Weg B: Demo-Fork |
|---|---|---|
| Repo | euer Firmen-Repo, eigener Branch | euer Fork von `dinooo13/habit-tracker-demo` |
| Ticket | ein echtes, kleines Ticket (1-2 Tage Arbeit) | Issue #1 „Kategorien für Habits mit Filter“, Schnelle danach Issue #2 |
| Branch | nach eurem Schema, z. B. `seminar/<KEY>-<slug>` | `seminar/kategorien` aus `origin/main` |
| Vorlage | [rheinwerk-starter-skills](https://github.com/dinooo13/rheinwerk-starter-skills) mit `<ANPASSEN>`-Stellen | Stufen-Branches `origin/stufe/01…10` als Musterlösung |
| Am Ende | die Skills liegen in eurem Repo | ihr kennt jede Zeile der Musterlösung |

Wechseln ist jederzeit erlaubt. Wer im Firmen-Repo hängt, macht die Übung in Weg B fertig und überträgt das Ergebnis danach.

**Einmal für alle:** die Vorlage neben eure Repos klonen. Sie wird ab Ü2 gebraucht. Im Fork- bzw. Firmen-Repo-Ordner ausführen, die Befehle ab Ü2 erwarten sie unter `../rheinwerk-starter-skills`:

```bash
git clone https://github.com/dinooo13/rheinwerk-starter-skills.git \
  ../rheinwerk-starter-skills
```

**Weg B, der Fork.** `gh repo fork … --clone` kopiert alle Branches. `origin` ist euer Fork, `upstream` das Kurs-Repo, und `gh` liest die Issues aus `upstream`.

```bash
gh repo fork dinooo13/habit-tracker-demo --clone
cd habit-tracker-demo
git branch -r | grep -c 'origin/stufe/'   # 10
```

Zeigt das `0`, wurde der Fork im Browser mit dem Haken „Copy the main branch only“ angelegt (dort standardmäßig gesetzt). Dann die Branches einmal aus dem Kurs-Repo in euren Fork schieben. Danach gelten alle Befehle mit `origin/` unverändert:

```bash
git remote add upstream \
  https://github.com/dinooo13/habit-tracker-demo.git 2>/dev/null
git fetch upstream
git push origin 'refs/remotes/upstream/stufe/*:refs/heads/stufe/*' \
  'refs/remotes/upstream/kurs/*:refs/heads/kurs/*'
git fetch origin
git branch -r | grep -c 'origin/stufe/'   # muss 10 zeigen
```

## Die Demo-App in 2 Minuten

Die Demo-App ist ein Habit-Tracker („Atomic Habit Tracker“). Sie läuft nur im Browser, ohne Backend. Die UI ist englisch.

1. Im Fork-Ordner `PORT=3110 npm run dev`, dann `localhost:3110/login` öffnen.
2. Login ist eine Attrappe ohne Felder: „Continue with demo login“ klicken. Ihr landet auf Today (`/app`).
3. „Settings“ (`/app/settings`), Abschnitt „Backup and restore“: „Load demo data“. Die Meldung „Demo data loaded“ erscheint, es gibt 7 Habits mit Verlauf.
4. „Today“ (`/app`): „Today's habit queue“ mit den Tabs „Open“ und „Reviewed“. Pro Habit gibt es „Done“, „Missed“ und „Skip“.
5. Bei einem Habit „Done“ klicken. Es wandert nach „Reviewed“, oben zählt „1 of 7 reviewed“ hoch. „Reopen“ macht es rückgängig.
6. „Habits“ (`/app/habits`): Liste aller Habits mit „Edit“ und „Archive“, oben „Create habit“.
7. „Create habit“: Pflicht sind „Habit name“, „Habit type“, „Identity statement“ (z. B. „I am a person who …“) und „Start date“. Speichern mit „Create habit“, „Edit“ speichert mit „Save changes“.
8. „Review“ (`/app/review`) sammelt verpasste Habits zur Reflexion, „Insights“ (`/app/insights`) zeigt Trends und Streaks.
9. Backup: „Settings“, „Backup and restore“ mit „Export JSON“ und „Import JSON“.

Auf Handy-Breite wandert die Navigation als Leiste an den unteren Rand.

**Tipps**

- **Zurücksetzen:** „Settings“, „Delete all data“, im Dialog „Delete all“. Die Daten liegen in der IndexedDB `habit-tracker` des Browsers, pro Port getrennt.
- **Port 3110:** Port 3000 ist bei vielen belegt und der Default von Playwright. Eine andere Portnummer heißt auch: leere Daten.
- **Neuladen prüft die Persistenz:** Was nach F5 weg ist, wurde nicht gespeichert.

**Hier landet Issue #1 „Kategorien für Habits mit Filter“:** Die Kategorie wählt man in „Create habit“ und „Edit habit“. Sichtbar wird sie auf den Karten unter „Habits“ und in der Queue auf „Today“. Beide Ansichten bekommen einen Filter, auf „Today“ wirkt er auf „Open“, „Reviewed“ und den Zähler „x of y reviewed“.

## Pro Tool: wo liegt was

Gemeinsamer Nenner sind `AGENTS.md` und `SKILL.md`. Schreibt die Skills einmal nach `.claude/skills/`. Cursor und die Copilot CLI lesen diesen Ordner mit. Codex braucht eine Kopie unter `.agents/skills/`, Copilot in VS Code womöglich eine unter `.github/skills/` (siehe unten).

| Konzept | Claude Code | Codex | Cursor | GitHub Copilot |
|---|---|---|---|---|
| Kontext-Datei | `CLAUDE.md`, sonst `AGENTS.md` | `AGENTS.md` | `AGENTS.md`, `CLAUDE.md`, `.cursor/rules/` | `AGENTS.md`, `CLAUDE.md`, `.github/copilot-instructions.md` |
| Skills | `.claude/skills/<name>/SKILL.md` | `.agents/skills/<name>/SKILL.md` | `.cursor/skills/`, liest `.claude/skills/` | `.github/skills/`. CLI liest auch `.claude/skills/`, VS Code ggf. nicht |
| Skill aufrufen | `/spec 1` | `$spec 1` (oder `/skills`) | `/spec 1` im Agent-Chat | `/spec 1` im Agent-Modus bzw. in der Copilot CLI |
| Subagenten | `.claude/agents/*.md` | `.codex/agents/*.toml` | `.cursor/agents/`, liest `.claude/agents/` | `.github/agents/*.agent.md` |
| Hooks | `.claude/settings.json` | `.codex/hooks.json` | `.cursor/hooks.json`, liest `.claude/settings.json` | `.github/hooks/*.json`, liest `.claude/settings.json` (VS Code: Preview) |
| Permissions | `.claude/settings.json`, `deny`, `ask`, `allow` | Sandbox- und Approval-Modus (`/permissions`) | Auto-Run mit Allowlist für Terminal-Befehle | Freigaben für Terminal-Befehle bzw. Tools |
| Neue Session | `/clear` oder neu starten | `/new` | neuer Chat (Cmd/Ctrl+N) | neuer Chat, CLI: `/clear` |

- **Claude Code** liest `AGENTS.md` ab Version 2.1.277, wenn es keine `CLAUDE.md` gibt. Als `CLAUDE.md` zählen dabei auch `.claude/CLAUDE.md` und `CLAUDE.local.md`. Gibt es eine davon, oder ist eure Version älter, schreibt in die `CLAUDE.md` die Zeile `@AGENTS.md`. Version prüfen: `claude --version`, aktualisieren: `claude update`.
- **Claude Code, Rechte:** Ab Version 2.1.283 starten interaktive Sessions im **Auto-Modus**. Dann prüft ein Klassifizierer-Modell die Aktionen statt euch, ihr seht viel weniger Rechte-Abfragen. Die Statuszeile zeigt `auto mode on`. Shift+Tab wechselt den Modus. Einzelfreigaben wie gewohnt: `claude --permission-mode default`.
- **Copilot in VS Code:** Die VS-Code-Doku nennt für den Standard-Harness (Copilot) nur `.github/skills/` als Projektordner. `.claude/skills/` steht dort nur beim Claude-Harness und bei den abgekündigten Local-Sessions. Erscheint `/spec` im Chat nicht, spiegelt die Skills und öffnet einen neuen Chat. Wie bei Codex: nach jeder Skill-Änderung neu spiegeln.

  ```bash
  mkdir -p .github && cp -R .claude/skills .github/
  diff -r .claude/skills .github/skills && echo synchron
  ```

- **Codex:** Nach jeder Änderung an einem Skill spiegeln. Fehlt der Skill danach in `/skills`, Codex neu starten:

  ```bash
  mkdir -p .agents && cp -R .claude/skills .agents/
  diff -r .claude/skills .agents/skills && echo synchron
  ```

  Codex setzt `$ARGUMENTS` nicht ein. Schreibt deshalb unter die Zeile mit `$ARGUMENTS` im Skill: `(In Codex, or if this line shows $ARGUMENTS literally, use the text the user gave.)`
- **Kein Hook im Tool oder von der Firma gesperrt?** Dieselbe Regel als Git-`pre-commit`-Hook (Blatt Ü7, Hilfe 2, und Guard-Vorlage). Das ist die tool-neutrale Variante, ihr verpasst nichts.
- **Persönliche Skills schlagen Projekt-Skills** mit gleichem Namen (Claude Code: `~/.claude/skills/`). Habt ihr dort schon `spec`, `code` oder `verify`, benennt den Ordner um oder verschiebt ihn, solange das Seminar läuft.

Details pro Übung stehen im Abschnitt „Pro Tool“ des jeweiligen Blatts.

## Optional: BMad Method

Kein Pflichtteil hängt an BMad. Zwei Bonusaufgaben vergleichen euren Flow mit [BMad Method](https://github.com/bmad-code-org/BMAD-METHOD/tree/V6.12) 6.12.4, beide nur in einem Wegwerf-Worktree:

- **Blatt Ü3, Bonus BMad:** dieselbe Spec mit `bmad-build` bis CHECKPOINT 1 („Approve and stop“) und mit eurer `/spec` vergleichen. Ohne Installation: die fertige BMad-Spec auf `origin/bmad/03-spec-bereit` lesen. Eure Freigabe bleibt `Approved-by: <eigener Name>` mit `docs(spec): approve <slug>`.
- **Blatt Ü6, Bonus BMad:** `bmad-code-review` mit einer eigenen Review-Ebene neben eurem `reviewer`.

Zum Selbstlernen nach dem Seminar liegen im Demo-Repo die Branches `bmad/02-installiert`, `bmad/03-spec-bereit`, `bmad/04-build`, `bmad/05-verify-hooks`, `bmad/06-review` und `bmad/07-retro`, jeder mit einer `BMAD.md`: was drin ist und wie man weitermacht. Dazu `bmad/epic-beispiel`, Issue #3 und #4 als ein Epic (`SPEC.md`, `stories.yaml`). Die `BMAD.md`-Dateien stammen aus einem BMad-Seminar und verweisen auf ein Blatt „BMad-Vorlagen“, das nicht in diesem Heft steht. Die Befehle in `BMAD.md` selbst reichen. Was dazukam, zeigt `git diff --stat origin/bmad/<vorher> origin/bmad/<dieser>`.

## Zurückgefallen? Auf den Stand der nächsten Übung springen

Niemand muss eine Übung fertig haben, um die nächste zu beginnen. Jedes Blatt hat unten einen Block **Rückfall**. Er arbeitet auf eurem Branch weiter und holt nur das fehlende Stück aus dem passenden Stufen-Branch.

Wer ganz neu einsteigen will (Weg B, z. B. nach einem kaputten Lauf), legt einen frischen Branch auf dem Stand vor der Übung an. Vorher eigene Reste sichern:

```bash
git add -A && git commit -m "wip: sichern"
```

Pro Einstieg ein Befehl (im Fork):

```bash
# Ü2
git switch --no-track -c seminar/kategorien origin/main
```

```bash
# Ü3
git switch --no-track -c seminar/ab-ue3 origin/stufe/01-spec-starter && \
  git checkout origin/stufe/02-spec-voll -- AGENTS.md && \
  git commit -m "docs: add AGENTS.md"
```

Ü4: Rückfall-Block auf [Blatt Ü3](ue3-spec-voll-und-freigabe.md#rückfall) (holt Spec-Skill v2 und die freigegebene Spec).

```bash
# Ü5
git switch --no-track -c seminar/ab-ue5 origin/seminar/ue4-code-parallel
```

```bash
# Ü6
git switch --no-track -c seminar/ab-ue6 origin/seminar/ue5-fix-list
```

```bash
# Ü7
git switch --no-track -c seminar/ab-ue7 origin/seminar/ue6-review-browser
```

Eure eigenen Skills nehmt ihr auf den neuen Branch mit, z. B.:

```bash
git checkout seminar/kategorien -- .claude/skills/spec
```

Weg A: Das Minimum steht im Rückfall-Block jedes Blatts. Meist heißt es „Datei aus der Vorlage übernehmen und die `<ANPASSEN>`-Stellen füllen“.

## Ports und Gates im Demo-Repo

- Dev-Server: `PORT=3110 npm run dev`, nie Port 3000.
- Gates:

  ```bash
  npm run lint && npm run typecheck && npm test
  PORT=3110 E2E_PORT=3110 npm run test:e2e
  ```

- Ein Dev-Server, der noch auf 3110 läuft, wird von den E2E-Tests wiederverwendet. Vor E2E stoppen: `lsof -i :3110` muss leer sein.
- Windows: WSL2 oder Git Bash. In PowerShell laufen die Befehle nicht.
